# Laboratorio AIOps de apiY con concurrencia red y PostgreSQL

Este paquete contiene un laboratorio guiado para Google Colab. El caso simula una degradación de `apiY` cuando un servicio de reportes genera tráfico concurrente sobre un enlace compartido y, al mismo tiempo, las solicitudes elevan la utilización del pool PostgreSQL.

## Archivos principales

- `Laboratorio_AIOps_APIY_Concurrencia_Red_DB_Jaeger_LLM.ipynb`: notebook del estudiante.
- `telemetria_apiY_concurrencia_db.csv`: 4320 registros de métricas por minuto.
- `logs_apiY_access.jsonl`: 24 access logs con atributos HTTP y correlación de trazas.
- `logs_postgresql_apiY.jsonl`: 12 eventos PostgreSQL normalizados.
- `logs_ipfix_netflow_apiY.jsonl`: 24 flujos con nombres de Information Elements IPFIX.
- `trazas_apiY_concurrencia_db_jaeger.json`: 12 trazas y 72 spans para Upload JSON de Jaeger.
- `trazas_apiY_concurrencia_db_otel.json`: las mismas trazas en OTLP JSON.
- `generar_datos_laboratorio.py`: regenerador determinista de todos los datos.
- `requirements.txt`: dependencias del notebook.

## Ejecución en Google Colab

1. Cargue el notebook en Colab.
2. Suba este paquete ZIP o los archivos sueltos cuando el notebook lo solicite.
3. Ejecute las celdas en orden.
4. Para acelerar Qwen, active una GPU T4 desde el tipo de entorno de ejecución.
5. En Jaeger Demo, use `Upload JSON` con el archivo que termina en `_jaeger.json`.

## Escenario del laboratorio

- Ventana UTC: 21 de octubre de 2026 de 14:00 a 15:29.
- Ventana Ecuador: 21 de octubre de 2026 de 09:00 a 10:29.
- Causa primaria guiada: tráfico concurrente del servicio de reportes y saturación del enlace compartido.
- Factor contribuyente: reintentos, utilización del pool, espera de conexiones y bloqueos PostgreSQL.
- Impacto: latencia p95, timeouts y respuestas HTTP 503/504.

La verdad se incluye para evaluar los detectores. El estudiante debe llegar a la hipótesis usando evidencia antes de consultar la etiqueta.

## Resultados de referencia

| Método | Alertas | TP | FP | FN | Precision | Recall | F1 |
|---|---:|---:|---:|---:|---:|---:|---:|
| Mediana y MAD | 100 | 89 | 11 | 1 | 0.890 | 0.989 | 0.937 |
| STL y residuo | 390 | 3 | 387 | 87 | 0.008 | 0.033 | 0.013 |
| Isolation Forest | 130 | 90 | 40 | 0 | 0.692 | 1.000 | 0.818 |
| LOF | 130 | 7 | 123 | 83 | 0.054 | 0.078 | 0.064 |

Los valores pueden cambiar ligeramente si una versión futura de las librerías modifica la implementación, aunque la semilla y los datos son deterministas.

## Nota sobre IPFIX y trazas

IPFIX no contiene normalmente un Trace ID. Los campos con prefijo `lab.` representan enriquecimiento realizado después de correlacionar tiempo, 5 tuplas y servicio. Los spans `ipfix.correlate shared-link` y `aiops.correlate-and-rank` son spans diagnósticos del laboratorio; no deben confundirse con llamadas reales de la aplicación.



