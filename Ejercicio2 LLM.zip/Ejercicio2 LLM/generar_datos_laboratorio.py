#!/usr/bin/env python3
"""Genera datos sintéticos para el laboratorio AIOps de apiY, red y PostgreSQL."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd


SEED = 20261021
BASE_DIR = Path(__file__).resolve().parent
CSV_NAME = "telemetria_apiY_concurrencia_db.csv"
IPFIX_NAME = "logs_ipfix_netflow_apiY.jsonl"
API_NAME = "logs_apiY_access.jsonl"
DB_NAME = "logs_postgresql_apiY.jsonl"
JAEGER_NAME = "trazas_apiY_concurrencia_db_jaeger.json"
OTEL_NAME = "trazas_apiY_concurrencia_db_otel.json"


def stable_hex(label: str, length: int) -> str:
    return hashlib.sha256(label.encode("utf-8")).hexdigest()[:length]


def clamp(values, low, high):
    return np.clip(values, low, high)


def tag(key, value):
    if isinstance(value, bool):
        value_type = "bool"
    elif isinstance(value, int):
        value_type = "int64"
    elif isinstance(value, float):
        value_type = "float64"
    else:
        value_type = "string"
    return {"key": key, "type": value_type, "value": value}


def otlp_any_value(value):
    if isinstance(value, bool):
        return {"boolValue": value}
    if isinstance(value, int):
        return {"intValue": str(value)}
    if isinstance(value, float):
        return {"doubleValue": value}
    return {"stringValue": str(value)}


def create_metrics() -> pd.DataFrame:
    rng = np.random.default_rng(SEED)
    timestamps = pd.date_range("2026-10-19 00:00:00+00:00", periods=4320, freq="min")
    n = len(timestamps)
    minute_day = timestamps.hour.to_numpy() * 60 + timestamps.minute.to_numpy()
    daily = np.sin(2 * np.pi * (minute_day - 420) / 1440)
    business = np.where((minute_day >= 480) & (minute_day <= 1080), 1.0, 0.25)

    start = pd.Timestamp("2026-10-21 14:00:00+00:00")
    end = pd.Timestamp("2026-10-21 15:29:00+00:00")
    incident = ((timestamps >= start) & (timestamps <= end)).astype(int)
    incident_index = np.flatnonzero(incident)
    phase = np.zeros(n)
    phase[incident_index] = np.linspace(0, 1, len(incident_index))
    bell = np.zeros(n)
    bell[incident_index] = np.sin(np.linspace(0, np.pi, len(incident_index)))

    # A short API-only degradation creates local anomalies outside the main incident.
    local_start = pd.Timestamp("2026-10-20 11:40:00+00:00")
    local_end = pd.Timestamp("2026-10-20 11:50:00+00:00")
    local_api = ((timestamps >= local_start) & (timestamps <= local_end)).astype(int)

    requests = 62 + 15 * business + 9 * daily + rng.normal(0, 2.8, n)
    concurrent = 38 + 12 * business + 7 * daily + rng.normal(0, 2, n)
    reporting_rps = 4 + 2 * business + rng.normal(0, 0.7, n)
    reporting_rps += incident * (55 + 28 * bell)
    concurrent += incident * (70 + 85 * bell)
    requests += incident * (38 + 18 * bell)

    link_util = 35 + 0.22 * requests + 0.25 * reporting_rps + rng.normal(0, 1.2, n)
    link_util += incident * (8 + 4 * bell)
    link_util = clamp(link_util, 25, 99.7)

    network_queue = np.maximum(link_util - 72, 0)
    rtt = 18 + 0.18 * network_queue + 0.12 * network_queue**2 + rng.normal(0, 1.2, n)
    rtt = clamp(rtt, 12, 280)
    packet_loss = 0.04 + 0.018 * np.maximum(link_util - 70, 0) ** 1.65 + rng.normal(0, 0.035, n)
    packet_loss = clamp(packet_loss, 0, 9.5)

    db_pool = 35 + 0.18 * requests + 0.10 * concurrent + rng.normal(0, 1.5, n)
    db_pool += incident * (10 + 12 * bell)
    db_pool = clamp(db_pool, 30, 99.6)
    db_connections = 18 + 0.72 * db_pool + rng.normal(0, 1.7, n)
    db_connections = clamp(db_connections, 15, 98)
    db_pool_wait = 1.5 + 0.19 * np.maximum(db_pool - 74, 0) ** 2 + rng.normal(0, 2.0, n)
    db_pool_wait = clamp(db_pool_wait, 0, 950)
    db_lock_wait = 2 + incident * (35 + 520 * bell) + rng.normal(0, 4, n)
    db_lock_wait += local_api * 8
    db_lock_wait = clamp(db_lock_wait, 0, 700)
    db_query_p95 = 72 + 0.52 * db_pool_wait + 0.68 * db_lock_wait + rng.normal(0, 8, n)
    db_query_p95 = clamp(db_query_p95, 40, 1600)

    retry_rate = 1.1 + 0.052 * network_queue + 0.46 * packet_loss + 0.013 * db_pool_wait + rng.normal(0, 0.18, n)
    retry_rate += local_api * 2.8
    retry_rate = clamp(retry_rate, 0.3, 28)
    timeout_rate = 0.25 + 0.030 * rtt + 0.010 * db_query_p95 + 0.25 * packet_loss + rng.normal(0, 0.12, n)
    timeout_rate += incident * (0.4 + 3.5 * bell) + local_api * 1.8
    timeout_rate = clamp(timeout_rate, 0.05, 18)
    error_rate = 0.65 + 0.90 * timeout_rate + 0.20 * retry_rate + rng.normal(0, 0.2, n)
    error_rate += local_api * 3.5
    error_rate = clamp(error_rate, 0.2, 24)
    latency = (
        70
        + 1.40 * rtt
        + 1.00 * db_query_p95
        + 1.00 * concurrent
        + 1.50 * db_pool_wait
        + 2.50 * np.maximum(concurrent - 80, 0)
        + rng.normal(0, 18, n)
    )
    latency += local_api * 320
    latency = clamp(latency, 100, 2800)
    success = requests * (1 - error_rate / 100) * (1 - timeout_rate / 100)

    stage = np.full(n, "normal", dtype=object)
    for idx in incident_index:
        mins = int((timestamps[idx] - start).total_seconds() / 60)
        if mins < 8:
            stage[idx] = "concurrency_spike"
        elif mins < 18:
            stage[idx] = "network_queue"
        elif mins < 65:
            stage[idx] = "db_pool_and_user_impact"
        else:
            stage[idx] = "partial_recovery"

    df = pd.DataFrame(
        {
            "timestamp": timestamps,
            "apiY_requests_per_sec": np.round(requests, 2),
            "apiY_success_rps": np.round(success, 2),
            "apiY_concurrent_requests": np.round(concurrent, 2),
            "apiY_latency_p95_ms": np.round(latency, 2),
            "apiY_http_error_rate_pct": np.round(error_rate, 3),
            "apiY_timeout_rate_pct": np.round(timeout_rate, 3),
            "apiY_retry_rate_pct": np.round(retry_rate, 3),
            "reporting_service_rps": np.round(reporting_rps, 2),
            "network_link_utilization_pct": np.round(link_util, 2),
            "network_rtt_ms": np.round(rtt, 2),
            "network_packet_loss_pct": np.round(packet_loss, 3),
            "db_active_connections": np.round(db_connections, 1),
            "db_pool_utilization_pct": np.round(db_pool, 2),
            "db_pool_wait_ms": np.round(db_pool_wait, 2),
            "db_query_p95_ms": np.round(db_query_p95, 2),
            "db_lock_wait_ms": np.round(db_lock_wait, 2),
            "is_incident": incident,
            "is_local_api_anomaly": local_api,
            "incident_stage": stage,
            "ground_truth_primary_cause": np.where(incident == 1, "concurrent_reporting_network_saturation", "none"),
            "ground_truth_contributing_cause": np.where(incident == 1, "db_pool_contention_and_retries", "none"),
        }
    )
    return df


def select_trace_rows(df: pd.DataFrame) -> pd.DataFrame:
    times = [
        "2026-10-21 13:40:00+00:00",
        "2026-10-21 14:00:00+00:00",
        "2026-10-21 14:05:00+00:00",
        "2026-10-21 14:12:00+00:00",
        "2026-10-21 14:20:00+00:00",
        "2026-10-21 14:32:00+00:00",
        "2026-10-21 14:45:00+00:00",
        "2026-10-21 14:58:00+00:00",
        "2026-10-21 15:10:00+00:00",
        "2026-10-21 15:22:00+00:00",
        "2026-10-21 15:40:00+00:00",
        "2026-10-21 16:10:00+00:00",
    ]
    indexed = df.set_index("timestamp")
    selected = indexed.loc[pd.to_datetime(times, utc=True)].reset_index()
    if "timestamp" not in selected.columns:
        selected = selected.rename(columns={selected.columns[0]: "timestamp"})
    return selected


def create_logs_and_traces(df: pd.DataFrame):
    trace_rows = select_trace_rows(df)
    api_logs = []
    db_logs = []
    ipfix_logs = []
    jaeger_traces = []
    otlp_spans_by_service: dict[str, list[dict]] = {}

    process_services = [
        "web-client",
        "api-gateway",
        "api-y",
        "postgresql",
        "network-observer",
        "aiops-analyzer",
    ]
    processes = {
        f"p{i+1}": {
            "serviceName": service,
            "tags": [tag("deployment.environment", "lab"), tag("service.version", "1.0.0")],
        }
        for i, service in enumerate(process_services)
    }
    process_id = {service: f"p{i+1}" for i, service in enumerate(process_services)}

    for position, row in trace_rows.iterrows():
        ts = pd.Timestamp(row["timestamp"])
        trace_id = stable_hex(f"apiY-trace-{ts.isoformat()}", 32)
        root_id = stable_hex(trace_id + "root", 16)
        gateway_id = stable_hex(trace_id + "gateway", 16)
        api_id = stable_hex(trace_id + "api", 16)
        db_id = stable_hex(trace_id + "db", 16)
        net_id = stable_hex(trace_id + "net", 16)
        aiops_id = stable_hex(trace_id + "aiops", 16)
        ids = [root_id, gateway_id, api_id, db_id, net_id, aiops_id]

        incident = int(row["is_incident"])
        status_code = 504 if row["apiY_timeout_rate_pct"] >= 8 else 503 if row["apiY_http_error_rate_pct"] >= 7 else 200
        status = "ERROR" if status_code >= 500 else "OK"
        root_ms = float(row["apiY_latency_p95_ms"]) * (0.94 + 0.02 * ((position % 3) - 1))
        gateway_ms = root_ms * 0.94
        api_ms = root_ms * 0.84
        db_ms = min(float(row["db_query_p95_ms"]), api_ms * 0.82)
        net_ms = min(root_ms * 0.77, float(row["network_rtt_ms"]) * 5.8 + float(row["network_packet_loss_pct"]) * 45)
        aiops_ms = 85 + 8 * position
        start_us = int(ts.timestamp() * 1_000_000)

        common_attrs = {
            "apiY.requests_per_sec": float(row["apiY_requests_per_sec"]),
            "apiY.concurrent_requests": float(row["apiY_concurrent_requests"]),
            "apiY.latency.p95_ms": float(row["apiY_latency_p95_ms"]),
            "http.error_rate_pct": float(row["apiY_http_error_rate_pct"]),
            "http.timeout_rate_pct": float(row["apiY_timeout_rate_pct"]),
            "http.retry_rate_pct": float(row["apiY_retry_rate_pct"]),
            "network.link.utilization_pct": float(row["network_link_utilization_pct"]),
            "network.rtt_ms": float(row["network_rtt_ms"]),
            "network.packet_loss_pct": float(row["network_packet_loss_pct"]),
            "db.client.connection.pool.utilization_pct": float(row["db_pool_utilization_pct"]),
            "db.client.connection.pool.wait_time_ms": float(row["db_pool_wait_ms"]),
            "db.query.p95_ms": float(row["db_query_p95_ms"]),
            "db.lock.wait_ms": float(row["db_lock_wait_ms"]),
            "incident.stage": str(row["incident_stage"]),
        }

        span_defs = [
            {
                "id": root_id,
                "parent": None,
                "service": "web-client",
                "operation": "HTTP GET /apiY/orders",
                "offset": 0,
                "duration": root_ms,
                "kind": "CLIENT",
                "attrs": {
                    "http.request.method": "GET",
                    "url.path": "/apiY/orders",
                    "http.response.status_code": status_code,
                    "otel.status_code": status,
                    **common_attrs,
                },
            },
            {
                "id": gateway_id,
                "parent": root_id,
                "service": "api-gateway",
                "operation": "GET /apiY/orders",
                "offset": 6,
                "duration": gateway_ms,
                "kind": "SERVER",
                "attrs": {
                    "http.request.method": "GET",
                    "url.path": "/apiY/orders",
                    "http.response.status_code": status_code,
                    "otel.status_code": status,
                    **common_attrs,
                },
            },
            {
                "id": api_id,
                "parent": gateway_id,
                "service": "api-y",
                "operation": "apiY.orders.list",
                "offset": 18,
                "duration": api_ms,
                "kind": "INTERNAL",
                "attrs": {
                    "code.function.name": "list_orders",
                    "otel.status_code": status,
                    **common_attrs,
                },
            },
            {
                "id": db_id,
                "parent": api_id,
                "service": "postgresql",
                "operation": "SELECT orders",
                "offset": 42,
                "duration": db_ms,
                "kind": "CLIENT",
                "attrs": {
                    "db.system.name": "postgresql",
                    "db.namespace": "orders",
                    "db.operation.name": "SELECT",
                    "db.query.summary": "SELECT orders by customer and date",
                    "db.client.connection.pool.utilization_pct": float(row["db_pool_utilization_pct"]),
                    "db.client.connection.pool.wait_time_ms": float(row["db_pool_wait_ms"]),
                    "db.query.duration_ms": float(row["db_query_p95_ms"]),
                    "db.lock.wait_ms": float(row["db_lock_wait_ms"]),
                    "otel.status_code": "ERROR" if status_code >= 500 and db_ms > 500 else "OK",
                },
            },
            {
                "id": net_id,
                "parent": root_id,
                "service": "network-observer",
                "operation": "ipfix.correlate shared-link",
                "offset": 12,
                "duration": net_ms,
                "kind": "INTERNAL",
                "attrs": {
                    "telemetry.source": "ipfix",
                    "correlation.method": "time-window-and-five-tuple",
                    "concurrent.service.name": "reporting-service",
                    "network.link.name": "wan-shared-200mbps",
                    "network.link.utilization_pct": float(row["network_link_utilization_pct"]),
                    "network.rtt_ms": float(row["network_rtt_ms"]),
                    "network.packet_loss_pct": float(row["network_packet_loss_pct"]),
                    "ipfix.reporting.octets": int(150_000 + float(row["reporting_service_rps"]) * 110_000),
                    "otel.status_code": "OK",
                },
            },
            {
                "id": aiops_id,
                "parent": root_id,
                "service": "aiops-analyzer",
                "operation": "aiops.correlate-and-rank",
                "offset": max(root_ms - aiops_ms - 8, 20),
                "duration": aiops_ms,
                "kind": "INTERNAL",
                "attrs": {
                    "ground_truth.incident": bool(incident),
                    "ground_truth.primary_cause": str(row["ground_truth_primary_cause"]),
                    "ground_truth.contributing_cause": str(row["ground_truth_contributing_cause"]),
                    "otel.status_code": "OK",
                },
            },
        ]

        jaeger_spans = []
        for span in span_defs:
            references = []
            if span["parent"]:
                references = [{"refType": "CHILD_OF", "traceID": trace_id, "spanID": span["parent"]}]
            span_tags = [tag("span.kind", span["kind"])] + [tag(k, v) for k, v in span["attrs"].items()]
            logs = []
            if status_code >= 500 and span["service"] in {"web-client", "api-gateway", "api-y"}:
                logs.append(
                    {
                        "timestamp": start_us + int((span["offset"] + span["duration"] - 2) * 1000),
                        "fields": [tag("event", "timeout_or_upstream_error"), tag("http.response.status_code", status_code)],
                    }
                )
            jaeger_span = {
                "traceID": trace_id,
                "spanID": span["id"],
                "operationName": span["operation"],
                "references": references,
                "startTime": start_us + int(span["offset"] * 1000),
                "duration": max(1000, int(span["duration"] * 1000)),
                "tags": span_tags,
                "logs": logs,
                "processID": process_id[span["service"]],
                "warnings": None,
            }
            jaeger_spans.append(jaeger_span)

            otlp_span = {
                "traceId": trace_id,
                "spanId": span["id"],
                "parentSpanId": span["parent"] or "",
                "name": span["operation"],
                "kind": {"CLIENT": 3, "SERVER": 2, "INTERNAL": 1}[span["kind"]],
                "startTimeUnixNano": str((start_us + int(span["offset"] * 1000)) * 1000),
                "endTimeUnixNano": str((start_us + int((span["offset"] + span["duration"]) * 1000)) * 1000),
                "attributes": [{"key": k, "value": otlp_any_value(v)} for k, v in span["attrs"].items()],
                "status": {"code": 2 if str(span["attrs"].get("otel.status_code")) == "ERROR" else 1},
            }
            otlp_spans_by_service.setdefault(span["service"], []).append(otlp_span)

        jaeger_traces.append(
            {"traceID": trace_id, "spans": jaeger_spans, "processes": processes, "warnings": None}
        )

        # API access logs follow OpenTelemetry HTTP semantic attribute names.
        for service, span_id, duration_ms in [
            ("api-gateway", gateway_id, gateway_ms),
            ("api-y", api_id, api_ms),
        ]:
            api_logs.append(
                {
                    "timestamp": ts.isoformat(),
                    "severity_text": "ERROR" if status_code >= 500 else "INFO",
                    "service.name": service,
                    "trace_id": trace_id,
                    "span_id": span_id,
                    "http.request.method": "GET",
                    "url.path": "/apiY/orders",
                    "http.response.status_code": status_code,
                    "http.server.request.duration_ms": round(duration_ms, 2),
                    "client.address": "10.20.1.25",
                    "server.address": "10.20.10.20" if service == "api-gateway" else "10.20.20.15",
                    "retry_count": int(round(float(row["apiY_retry_rate_pct"]) / 4)),
                    "timeout": bool(status_code == 504),
                }
            )

        db_logs.append(
            {
                "timestamp": (ts + pd.Timedelta(milliseconds=42)).isoformat(),
                "user_name": "api_y_user",
                "database_name": "orders",
                "process_id": 22000 + position,
                "connection_from": "10.20.20.15:54320",
                "session_id": stable_hex(trace_id + "session", 12),
                "session_line_num": 1,
                "command_tag": "SELECT",
                "session_start_time": (ts - pd.Timedelta(minutes=10)).isoformat(),
                "virtual_transaction_id": f"{position + 2}/17",
                "transaction_id": 80000 + position,
                "error_severity": "ERROR" if status_code >= 500 and db_ms > 500 else "LOG",
                "sql_state_code": "57014" if status_code == 504 else "00000",
                "message": "canceling statement due to statement timeout" if status_code == 504 else "statement completed",
                "detail": "connection pool wait and lock wait observed" if incident else "normal execution",
                "application_name": "api-y",
                "backend_type": "client backend",
                "query_id": stable_hex("SELECT orders by customer and date", 16),
                "query": "SELECT id,status,total FROM orders WHERE customer_id=$1 AND created_at >= $2",
                "duration_ms": round(db_ms, 2),
                "lock_wait_ms": float(row["db_lock_wait_ms"]),
                "connection_pool_wait_ms": float(row["db_pool_wait_ms"]),
                "trace_id": trace_id,
                "span_id": db_id,
            }
        )

        # IPFIX-normalized records. IPFIX has no trace_id; correlation fields are lab metadata.
        flow_start = int(ts.timestamp() * 1000)
        duration_ms = int(max(50, root_ms))
        api_db_octets = int(25_000 + float(row["apiY_requests_per_sec"]) * 950)
        report_octets = int(150_000 + float(row["reporting_service_rps"]) * 110_000)
        for flow_no, record in enumerate(
            [
                {
                    "sourceIPv4Address": "10.20.20.15",
                    "destinationIPv4Address": "10.20.30.10",
                    "sourceTransportPort": 54320 + position,
                    "destinationTransportPort": 5432,
                    "applicationName": "postgresql",
                    "octetDeltaCount": api_db_octets,
                    "packetDeltaCount": max(20, api_db_octets // 1100),
                },
                {
                    "sourceIPv4Address": "10.20.40.12",
                    "destinationIPv4Address": "172.20.50.30",
                    "sourceTransportPort": 45000 + position,
                    "destinationTransportPort": 443,
                    "applicationName": "reporting-service-object-storage",
                    "octetDeltaCount": report_octets,
                    "packetDeltaCount": max(40, report_octets // 1200),
                },
            ]
        ):
            ipfix_logs.append(
                {
                    "ipfixVersion": 10,
                    "observationDomainId": 1001,
                    "exportingProcessId": 7,
                    "flowId": int(stable_hex(trace_id + f"flow{flow_no}", 12), 16),
                    "flowStartMilliseconds": flow_start,
                    "flowEndMilliseconds": flow_start + duration_ms,
                    "protocolIdentifier": 6,
                    "tcpControlBits": 24 if status_code == 200 else 20,
                    **record,
                    "ingressInterface": 12,
                    "egressInterface": 20,
                    "lab.correlation.window_seconds": 2,
                    "lab.related_trace_id": trace_id,
                    "lab.note": "related_trace_id is enrichment added after correlation; it is not a standard IPFIX field",
                }
            )

    otlp = {"resourceSpans": []}
    for service, spans in otlp_spans_by_service.items():
        otlp["resourceSpans"].append(
            {
                "resource": {
                    "attributes": [
                        {"key": "service.name", "value": {"stringValue": service}},
                        {"key": "deployment.environment.name", "value": {"stringValue": "lab"}},
                    ]
                },
                "scopeSpans": [
                    {
                        "scope": {"name": "lab.log-to-trace.correlator", "version": "1.0.0"},
                        "spans": spans,
                    }
                ],
            }
        )

    jaeger = {
        "data": jaeger_traces,
        "total": len(jaeger_traces),
        "limit": 0,
        "offset": 0,
        "errors": None,
    }
    return api_logs, db_logs, ipfix_logs, jaeger, otlp


def write_jsonl(path: Path, records):
    with path.open("w", encoding="utf-8") as file:
        for record in records:
            file.write(json.dumps(record, ensure_ascii=False) + "\n")


def main():
    BASE_DIR.mkdir(parents=True, exist_ok=True)
    df = create_metrics()
    df.to_csv(BASE_DIR / CSV_NAME, index=False)
    api_logs, db_logs, ipfix_logs, jaeger, otlp = create_logs_and_traces(df)
    write_jsonl(BASE_DIR / API_NAME, api_logs)
    write_jsonl(BASE_DIR / DB_NAME, db_logs)
    write_jsonl(BASE_DIR / IPFIX_NAME, ipfix_logs)
    (BASE_DIR / JAEGER_NAME).write_text(json.dumps(jaeger, ensure_ascii=False, indent=2), encoding="utf-8")
    (BASE_DIR / OTEL_NAME).write_text(json.dumps(otlp, ensure_ascii=False, indent=2), encoding="utf-8")
    summary = {
        "metric_rows": len(df),
        "api_logs": len(api_logs),
        "db_logs": len(db_logs),
        "ipfix_records": len(ipfix_logs),
        "traces": len(jaeger["data"]),
        "spans": sum(len(t["spans"]) for t in jaeger["data"]),
        "incident_start_utc": str(df.loc[df.is_incident.eq(1), "timestamp"].min()),
        "incident_end_utc": str(df.loc[df.is_incident.eq(1), "timestamp"].max()),
    }
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
