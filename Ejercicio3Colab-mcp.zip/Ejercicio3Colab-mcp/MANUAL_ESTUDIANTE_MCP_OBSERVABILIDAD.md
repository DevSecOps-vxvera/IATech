# Manual del estudiante

## Laboratorio MCP, NetFlow, logs web, OpenTelemetry y LLM

### 1. Propósito

El laboratorio demuestra cómo un agente de análisis puede consultar telemetría mediante Model Context Protocol sin exponer un servidor público. El servidor MCP, el cliente y el modelo se ejecutan dentro de Google Colab.

El estudiante correlacionará datos de red y aplicación, construirá trazas, generará hipótesis mediante un LLM pequeño y comparará esas hipótesis con una verificación manual.

### 2. Duración y requisitos

- Duración: 4 horas.
- Cuenta gratuita de Google con acceso a Colab.
- Navegador actualizado.
- El uso de GPU es opcional; mejora el paso del LLM.
- No se requieren API keys.

### 3. Escenario

La aplicación presenta lentitud y errores 503/504 entre las 14:00 y 14:44 UTC. Durante el mismo intervalo, un cliente de reportes ejecuta `/api/reports/export` y recibe archivos de gran tamaño.

Debe investigar si el problema comienza en la red, en el servidor web o en otro componente no observado.

### 4. Archivos y función

| Archivo | Función |
|---|---|
| `Laboratorio_MCP_NetFlow_Web_OpenTelemetry_LLM_Colab.ipynb` | Notebook principal |
| `servidor_mcp_observabilidad.py` | Servidor MCP local con siete herramientas |
| `cliente_mcp_demo.py` | Cliente de prueba mediante `stdio` |
| `generar_datos_mcp.py` | Regenera todos los datos con semilla fija |
| `metricas_mcp_observabilidad.csv` | Métricas agregadas por minuto |
| `netflow_ipfix.jsonl` | Flujos con nombres de Information Elements IPFIX |
| `nginx_access_combined.log` | Access log NGINX Combined extendido |
| `web_access_estructurado.jsonl` | Versión normalizada para consulta |
| `trazas_mcp_otlp.json` | Trazas en OTLP JSON |
| `trazas_mcp_jaeger.json` | Trazas para la función de carga JSON de Jaeger |
| `manifiesto_laboratorio.json` | Escenario, archivos y verdad sintética |
| `Infografia_MCP_Observabilidad_IA_Colab.png` | Infografía horizontal para presentación |

### 5. Ejecución

1. Descargue el ZIP completo.
2. Abra el notebook en Google Colab.
3. Si desea GPU, seleccione **Entorno de ejecución → Cambiar tipo de entorno de ejecución → GPU**.
4. Ejecute la instalación de dependencias.
5. Cuando se solicite, suba el mismo ZIP del laboratorio.
6. Ejecute las celdas en orden.
7. No modifique la ventana del incidente hasta completar la primera comparación.

### 6. Herramientas MCP

| Herramienta | Resultado |
|---|---|
| `inventario_fuentes` | Archivos disponibles y reglas de correlación |
| `consultar_netflow` | Flujos filtrados por tiempo, IP y puerto |
| `consultar_logs_web` | Solicitudes filtradas por ruta, estado y tiempo |
| `resumir_ventana` | Resumen conjunto de red y web |
| `correlacionar_incidente` | Hechos, correlaciones e hipótesis candidatas |
| `obtener_evidencia_traza` | Access log, flujo relacionado y traza |
| `preparar_contexto_llm` | Evidencia compacta para el modelo |

### 7. Qué se espera observar

| Métrica | Línea base aproximada | Incidente aproximado |
|---|---:|---:|
| Reportes por segundo | 3,41 | 56,55 |
| Utilización del enlace | 42,10 % | 94,47 % |
| Retransmisiones TCP | 0,26 % | 4,11 % |
| Latencia web p95 | 191 ms | 960 ms |
| Errores HTTP | 1,33 % | 9,85 % |
| Conexiones activas | 29 | 138 |

Durante el incidente hay 135 solicitudes web sintéticas, 42 respuestas 5xx y aproximadamente 1,43 GB transferidos por la ruta de reportes.

### 8. Interpretación correcta

NetFlow/IPFIX demuestra que existieron flujos, sus extremos, duración, protocolo, paquetes y octetos. No demuestra directamente qué función de la aplicación produjo cada flujo ni contiene un `trace_id` estándar.

El laboratorio correlaciona cada solicitud utilizando tiempo, IP, puerto y servicio. Por esa razón, los spans de red incluyen:

- `lab.inferred_span=true`;
- `lab.evidence.source=IPFIX temporal/IP correlation`.

La presencia de estos atributos obliga a reconocer que el span fue reconstruido.

### 9. Resultado esperado

La hipótesis mejor respaldada es la saturación del enlace compartido por respuestas grandes de `/api/reports/export`. La retransmisión TCP y la acumulación de conexiones agravan la latencia y contribuyen a los 503/504.

Esto es una causa probable, no una causa confirmada. La prueba principal consiste en limitar o pausar temporalmente las exportaciones mientras se mantiene una carga comparable de `/api/orders`.

La hipótesis se fortalece si descienden simultáneamente:

- utilización del enlace;
- retransmisiones;
- latencia p95;
- conexiones activas;
- errores 503/504.

### 10. Evaluación del LLM

El modelo debe:

1. citar valores del contexto MCP;
2. diferenciar hechos e inferencias;
3. proponer más de una hipótesis;
4. reconocer la información faltante;
5. ofrecer una prueba de refutación;
6. evitar afirmar que NetFlow contenía el `trace_id`.

Una respuesta bien redactada no es necesariamente correcta. Compare cada afirmación con los logs, métricas y spans.

### 11. Uso de Jaeger

1. Descargue `trazas_mcp_jaeger.json`.
2. Abra <https://demo.jaegertracing.io/jaeger/>.
3. Utilice la carga de JSON.
4. Revise los servicios `nginx`, `api-service` y `network-correlation`.
5. Compare duración, estado HTTP y atributos de una traza normal frente a una traza del incidente.

### 12. Seguridad

- El servidor MCP utiliza `stdio` y no abre puertos.
- Los datos son completamente sintéticos.
- No copie logs reales en el notebook sin anonimizar direcciones, tokens, cookies, consultas o datos personales.
- No exponga `otlp-mcp` u otro collector sin autenticación directamente a Internet.
- Limite el contexto que se entrega al modelo; el LLM recibe un resumen, no todos los logs.

### 13. Preguntas de cierre

1. ¿Qué evidencia sitúa la red antes que los errores web en la cadena causal?
2. ¿Qué evidencia adicional permitiría descartar saturación de CPU del servidor?
3. ¿Qué afirmación del LLM fue más difícil de validar?
4. ¿Qué atributos deben anonimizarse con datos reales?
5. ¿Qué cambiaría si el MCP se desplegara para varios equipos?

