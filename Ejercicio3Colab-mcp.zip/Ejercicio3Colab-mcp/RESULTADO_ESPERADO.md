# Resultado esperado del laboratorio

## Diagnóstico resumido

La exportación concurrente de reportes incrementa el tráfico hasta llevar el enlace compartido a una utilización media aproximada de 94,47 %. En el mismo intervalo aumentan las retransmisiones TCP a 4,11 %, la latencia web p95 a 960 ms, las conexiones activas a 138 y los errores HTTP a 9,85 %.

La evidencia correlacionada respalda como causa primaria probable la saturación del enlace por respuestas grandes de `/api/reports/export`. Las retransmisiones y la acumulación de conexiones actúan como factores contribuyentes. Los errores 503/504 son síntomas del incidente.

## Límites de la conclusión

- NetFlow no contiene un `trace_id` estándar.
- Los spans de red son inferidos por tiempo, direcciones y puerto.
- No hay métricas de CPU o memoria del servidor.
- Una correlación temporal no confirma por sí sola causalidad.

## Prueba de confirmación

Limitar temporalmente el ancho de banda o la concurrencia de `/api/reports/export`, manteniendo una carga comparable sobre `/api/orders`. La hipótesis se fortalece si disminuyen simultáneamente la utilización, las retransmisiones, la latencia y los errores. Se debilita si el impacto continúa sin variación.

## Evaluación mínima del LLM

El LLM debe mencionar los valores principales, distinguir hechos de inferencias, proponer hipótesis competidoras, reconocer datos faltantes y recomendar una prueba capaz de refutar su diagnóstico.

