#!/usr/bin/env python3
"""Cliente MCP de demostración: ejecuta herramientas y guarda evidencia compacta."""

from __future__ import annotations

import asyncio
import json
import os
import sys
from pathlib import Path

from mcp import Client, StdioServerParameters
from mcp.client.stdio import stdio_client


BASE = Path(__file__).resolve().parent
SERVER = BASE / "servidor_mcp_observabilidad.py"


def normalize(result):
    if result.structured_content is not None:
        value = result.structured_content
        if isinstance(value, dict) and set(value) == {"result"}:
            return value["result"]
        return value
    texts = [getattr(block, "text", "") for block in result.content]
    joined = "\n".join(x for x in texts if x)
    try:
        return json.loads(joined)
    except json.JSONDecodeError:
        return {"text": joined, "is_error": result.is_error}


async def main() -> None:
    env = os.environ.copy()
    env["LAB_DATA_DIR"] = str(BASE)
    params = StdioServerParameters(command=sys.executable, args=[str(SERVER)], env=env)
    async with Client(stdio_client(params)) as client:
        listing = await client.list_tools()
        tools = [tool.name for tool in listing.tools]
        inventory = normalize(await client.call_tool("inventario_fuentes", {}))
        context = normalize(await client.call_tool("preparar_contexto_llm", {
            "inicio": "2026-10-21T14:00:00Z",
            "fin": "2026-10-21T14:44:59Z",
        }))
        payload = {"mcp_tools": tools, "inventory": inventory, "llm_context": context}
        (BASE / "evidencia_mcp.json").write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        print(json.dumps({"connected": True, "tools": tools, "output": "evidencia_mcp.json"}, ensure_ascii=False))


if __name__ == "__main__":
    asyncio.run(main())
