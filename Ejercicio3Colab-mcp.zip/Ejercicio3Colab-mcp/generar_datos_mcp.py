#!/usr/bin/env python3
"""Genera datos deterministas para el laboratorio MCP de observabilidad."""

from __future__ import annotations

import hashlib
import json
import math
import random
from datetime import datetime, timedelta, timezone
from pathlib import Path

import numpy as np
import pandas as pd


BASE = Path(__file__).resolve().parent
RNG = np.random.default_rng(20261021)
PY_RNG = random.Random(20261021)
START = datetime(2026, 10, 21, 13, 0, tzinfo=timezone.utc)
INCIDENT_START = datetime(2026, 10, 21, 14, 0, tzinfo=timezone.utc)
INCIDENT_END = datetime(2026, 10, 21, 14, 44, tzinfo=timezone.utc)
SERVER_IP = "10.20.0.10"
GATEWAY_IP = "10.20.0.5"
REPORT_CLIENT = "203.0.113.77"
NORMAL_CLIENTS = ["198.51.100.11", "198.51.100.12", "198.51.100.13"]


def hex_id(seed: str, length: int) -> str:
    return hashlib.sha256(seed.encode()).hexdigest()[:length]


def iso(ts: datetime) -> str:
    return ts.isoformat().replace("+00:00", "Z")


def in_incident(ts: datetime) -> bool:
    return INCIDENT_START <= ts <= INCIDENT_END


def generate_metrics() -> pd.DataFrame:
    rows = []
    for minute in range(180):
        ts = START + timedelta(minutes=minute)
        incident = in_incident(ts)
        wave = math.sin(minute / 11) * 2.0
        report_rps = max(0.5, RNG.normal(3.5, 0.8))
        requests = max(20, RNG.normal(63 + wave, 4.5))
        bandwidth = np.clip(RNG.normal(42, 5), 25, 65)
        retrans = np.clip(RNG.normal(0.25, 0.09), 0.03, 0.7)
        latency = max(80, RNG.normal(190, 24))
        error = np.clip(RNG.normal(1.4, 0.45), 0.1, 3.0)
        active = max(8, RNG.normal(29, 4))
        if incident:
            phase = (ts - INCIDENT_START).total_seconds() / 60
            report_rps = np.clip(RNG.normal(52 + 0.22 * phase, 4), 44, 68)
            requests = np.clip(RNG.normal(112, 8), 90, 132)
            bandwidth = np.clip(RNG.normal(94.5, 2.5), 87, 99.8)
            retrans = np.clip(RNG.normal(4.1, 0.75), 2.2, 6.5)
            latency = np.clip(RNG.normal(980, 170), 610, 1420)
            error = np.clip(RNG.normal(9.8, 2.0), 5.2, 15.5)
            active = np.clip(RNG.normal(138, 17), 95, 182)
        rows.append({
            "timestamp": iso(ts),
            "requests_rps": round(float(requests), 3),
            "report_rps": round(float(report_rps), 3),
            "link_utilization_pct": round(float(bandwidth), 3),
            "tcp_retransmissions_pct": round(float(retrans), 3),
            "web_latency_p95_ms": round(float(latency), 3),
            "http_error_pct": round(float(error), 3),
            "active_connections": round(float(active), 3),
            "incident_truth": int(incident),
        })
    df = pd.DataFrame(rows)
    df.to_csv(BASE / "metricas_mcp_observabilidad.csv", index=False)
    return df


def generate_logs_and_traces(metrics: pd.DataFrame) -> None:
    netflow = []
    web_json = []
    combined = []
    trace_specs = []

    for minute, row in metrics.iterrows():
        ts = datetime.fromisoformat(row.timestamp.replace("Z", "+00:00"))
        incident = bool(row.incident_truth)
        client = REPORT_CLIENT if incident else NORMAL_CLIENTS[minute % len(NORMAL_CLIENTS)]
        src_port = 41000 + minute
        duration_ms = int(800 + row.web_latency_p95_ms * (1.5 if incident else 0.7))
        bytes_flow = int((row.link_utilization_pct / 100) * 1_000_000_000 / 8 * 60)
        packets = max(1, int(bytes_flow / 1180))
        flow_id = hex_id(f"flow-{minute}", 16)
        netflow.append({
            "observationDomainId": 1001,
            "flowId": flow_id,
            "sourceIPv4Address": client,
            "destinationIPv4Address": SERVER_IP,
            "sourceTransportPort": src_port,
            "destinationTransportPort": 443,
            "protocolIdentifier": 6,
            "octetDeltaCount": bytes_flow,
            "packetDeltaCount": packets,
            "tcpControlBits": 27 if incident else 24,
            "flowStartMilliseconds": int(ts.timestamp() * 1000),
            "flowEndMilliseconds": int((ts + timedelta(milliseconds=duration_ms)).timestamp() * 1000),
            "ingressInterface": 3,
            "egressInterface": 7,
            "lab.estimated_link_utilization_pct": row.link_utilization_pct,
            "lab.estimated_retransmissions_pct": row.tcp_retransmissions_pct,
            "lab.note": "Los campos lab.* son enriquecimientos, no Information Elements IPFIX estándar.",
        })

        request_count = 3 if incident else 2
        for seq in range(request_count):
            offset = 5 + seq * 12
            req_ts = ts + timedelta(seconds=offset)
            request_id = hex_id(f"request-{minute}-{seq}", 20)
            trace_id = hex_id(f"trace-{minute}-{seq}", 32)
            span_id = hex_id(f"span-root-{minute}-{seq}", 16)
            if incident and seq == 0:
                path = "/api/reports/export"
                status = 200
                response_bytes = int(RNG.normal(32_000_000, 3_000_000))
                request_time = round(float(RNG.normal(4.4, 0.45)), 3)
                upstream_time = round(request_time * 0.79, 3)
            elif incident:
                path = "/api/orders"
                status = 504 if minute % 3 == 0 else 503 if minute % 5 == 0 else 200
                response_bytes = max(300, int(RNG.normal(2300, 400)))
                request_time = round(float(np.clip(RNG.normal(1.18, 0.25), 0.65, 1.9)), 3)
                upstream_time = round(request_time * 0.72, 3)
            else:
                path = "/api/orders" if seq == 0 else "/api/catalog"
                status = 200
                response_bytes = max(500, int(RNG.normal(6200, 900)))
                request_time = round(float(np.clip(RNG.normal(0.18, 0.035), 0.08, 0.32)), 3)
                upstream_time = round(request_time * 0.58, 3)
            user_agent = "reporting-client/2.1" if path.startswith("/api/reports") else "student-client/1.0"
            record = {
                "timestamp": iso(req_ts),
                "remote_addr": client,
                "request": f"GET {path} HTTP/1.1",
                "http_request_method": "GET",
                "url_path": path,
                "status": status,
                "body_bytes_sent": response_bytes,
                "http_referer": "-",
                "http_user_agent": user_agent,
                "request_time": request_time,
                "upstream_response_time": upstream_time,
                "request_id": request_id,
                "trace_id": trace_id,
                "span_id": span_id,
                "server_address": "api.lab.local",
                "server_port": 443,
            }
            web_json.append(record)
            local = req_ts.strftime("%d/%b/%Y:%H:%M:%S +0000")
            combined.append(
                f'{client} - - [{local}] "GET {path} HTTP/1.1" {status} {response_bytes} '
                f'"-" "{user_agent}" request_time={request_time} upstream_response_time={upstream_time} '
                f'request_id={request_id} trace_id={trace_id}'
            )
            if minute in {10, 25, 40, 55, 61, 67, 73, 79, 85, 91, 97, 103, 109, 115, 130, 150} and seq == 0:
                trace_specs.append(record | {
                    "flow_id": flow_id,
                    "link_utilization_pct": float(row.link_utilization_pct),
                    "retransmissions_pct": float(row.tcp_retransmissions_pct),
                    "incident": incident,
                })

    for name, rows in [
        ("netflow_ipfix.jsonl", netflow),
        ("web_access_estructurado.jsonl", web_json),
    ]:
        (BASE / name).write_text("\n".join(json.dumps(x, ensure_ascii=False) for x in rows) + "\n", encoding="utf-8")
    (BASE / "nginx_access_combined.log").write_text("\n".join(combined) + "\n", encoding="utf-8")
    build_traces(trace_specs)


def tag(key: str, value):
    if isinstance(value, bool):
        return {"key": key, "type": "bool", "value": value}
    if isinstance(value, int):
        return {"key": key, "type": "int64", "value": value}
    if isinstance(value, float):
        return {"key": key, "type": "float64", "value": value}
    return {"key": key, "type": "string", "value": str(value)}


def otlp_attr(key: str, value):
    if isinstance(value, bool):
        v = {"boolValue": value}
    elif isinstance(value, int):
        v = {"intValue": str(value)}
    elif isinstance(value, float):
        v = {"doubleValue": value}
    else:
        v = {"stringValue": str(value)}
    return {"key": key, "value": v}


def build_traces(specs: list[dict]) -> None:
    jaeger_data = []
    otlp_by_service: dict[str, list] = {"nginx": [], "api-service": [], "network-correlation": []}
    for item in specs:
        tid = item["trace_id"]
        root = item["span_id"]
        api_span = hex_id(tid + "api", 16)
        net_span = hex_id(tid + "net", 16)
        start_us = int(datetime.fromisoformat(item["timestamp"].replace("Z", "+00:00")).timestamp() * 1_000_000)
        total_us = int(item["request_time"] * 1_000_000)
        api_us = int(item["upstream_response_time"] * 1_000_000)
        net_us = max(1000, total_us - api_us)
        status = item["status"]
        common = {
            "http.request.method": "GET",
            "url.path": item["url_path"],
            "http.response.status_code": status,
            "client.address": item["remote_addr"],
            "server.address": item["server_address"],
            "server.port": item["server_port"],
            "lab.request_id": item["request_id"],
            "lab.incident_truth": item["incident"],
        }
        spans = [
            {
                "traceID": tid, "spanID": root, "operationName": f"GET {item['url_path']}",
                "references": [], "startTime": start_us, "duration": total_us,
                "tags": [tag(k, v) for k, v in common.items()] + [tag("span.kind", "server"), tag("error", status >= 500), tag("lab.evidence.source", "nginx_access")],
                "logs": [], "processID": "p1", "warnings": None,
            },
            {
                "traceID": tid, "spanID": api_span, "operationName": "api-service process",
                "references": [{"refType": "CHILD_OF", "traceID": tid, "spanID": root}],
                "startTime": start_us + 2000, "duration": api_us,
                "tags": [tag("span.kind", "internal"), tag("http.response.status_code", status), tag("lab.evidence.source", "nginx upstream_response_time"), tag("lab.inferred_span", True)],
                "logs": [], "processID": "p2", "warnings": None,
            },
            {
                "traceID": tid, "spanID": net_span, "operationName": "correlated network flow",
                "references": [{"refType": "CHILD_OF", "traceID": tid, "spanID": root}],
                "startTime": start_us + api_us, "duration": net_us,
                "tags": [tag("span.kind", "internal"), tag("network.transport", "tcp"), tag("lab.flow_id", item["flow_id"]), tag("lab.link_utilization_pct", item["link_utilization_pct"]), tag("lab.retransmissions_pct", item["retransmissions_pct"]), tag("lab.evidence.source", "IPFIX temporal/IP correlation"), tag("lab.inferred_span", True)],
                "logs": [], "processID": "p3", "warnings": None,
            },
        ]
        jaeger_data.append({
            "traceID": tid,
            "spans": spans,
            "processes": {
                "p1": {"serviceName": "nginx", "tags": [tag("deployment.environment.name", "lab-colab")]},
                "p2": {"serviceName": "api-service", "tags": [tag("deployment.environment.name", "lab-colab")]},
                "p3": {"serviceName": "network-correlation", "tags": [tag("deployment.environment.name", "lab-colab")]},
            },
            "warnings": None,
        })

        for service, sid, parent, name, dur, attrs, kind in [
            ("nginx", root, "", f"GET {item['url_path']}", total_us, common | {"lab.evidence.source": "nginx_access"}, 2),
            ("api-service", api_span, root, "api-service process", api_us, {"http.response.status_code": status, "lab.evidence.source": "nginx upstream_response_time", "lab.inferred_span": True}, 1),
            ("network-correlation", net_span, root, "correlated network flow", net_us, {"network.transport": "tcp", "lab.flow_id": item["flow_id"], "lab.link_utilization_pct": item["link_utilization_pct"], "lab.retransmissions_pct": item["retransmissions_pct"], "lab.evidence.source": "IPFIX temporal/IP correlation", "lab.inferred_span": True}, 1),
        ]:
            otlp_by_service[service].append({
                "traceId": tid, "spanId": sid, **({"parentSpanId": parent} if parent else {}),
                "name": name, "kind": kind,
                "startTimeUnixNano": str(start_us * 1000),
                "endTimeUnixNano": str((start_us + dur) * 1000),
                "attributes": [otlp_attr(k, v) for k, v in attrs.items()],
                "status": {"code": 2 if status >= 500 else 1},
            })

    jaeger = {"data": jaeger_data, "total": len(jaeger_data), "limit": 0, "offset": 0, "errors": None}
    (BASE / "trazas_mcp_jaeger.json").write_text(json.dumps(jaeger, ensure_ascii=False, indent=2), encoding="utf-8")
    resource_spans = []
    for service, spans in otlp_by_service.items():
        resource_spans.append({
            "resource": {"attributes": [otlp_attr("service.name", service), otlp_attr("deployment.environment.name", "lab-colab")]},
            "scopeSpans": [{"scope": {"name": "lab.mcp.correlation", "version": "1.0.0"}, "spans": spans}],
        })
    (BASE / "trazas_mcp_otlp.json").write_text(json.dumps({"resourceSpans": resource_spans}, ensure_ascii=False, indent=2), encoding="utf-8")


def main() -> None:
    metrics = generate_metrics()
    generate_logs_and_traces(metrics)
    manifest = {
        "scenario": "Congestión por exportación concurrente de reportes",
        "window_utc": [iso(INCIDENT_START), iso(INCIDENT_END)],
        "ground_truth": {
            "primary_cause": "Saturación del enlace por respuestas grandes de /api/reports/export",
            "contributing_factor": "Retransmisiones TCP y acumulación de conexiones",
            "symptoms": ["latencia p95 elevada", "HTTP 503/504", "solicitudes concurrentes"],
        },
        "files": [
            "metricas_mcp_observabilidad.csv", "netflow_ipfix.jsonl",
            "nginx_access_combined.log", "web_access_estructurado.jsonl",
            "trazas_mcp_jaeger.json", "trazas_mcp_otlp.json",
        ],
    }
    (BASE / "manifiesto_laboratorio.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"metric_rows": len(metrics), "incident_rows": int(metrics.incident_truth.sum()), "status": "OK"}, ensure_ascii=False))


if __name__ == "__main__":
    main()
