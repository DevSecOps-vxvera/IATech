#!/usr/bin/env python3
"""Servidor MCP local para consultar y correlacionar telemetría del laboratorio.

No escriba mensajes con print() en este archivo: stdout transporta mensajes MCP.
"""

from __future__ import annotations

import json
import logging
import os
from datetime import datetime
from pathlib import Path
from typing import Any

import pandas as pd
from mcp.server import MCPServer


logging.basicConfig(level=logging.WARNING)
logger = logging.getLogger(__name__)
mcp = MCPServer("observabilidad-netflow-web")


def data_dir() -> Path:
    return Path(os.environ.get("LAB_DATA_DIR", Path(__file__).resolve().parent)).resolve()


def read_jsonl(name: str) -> list[dict[str, Any]]:
    path = data_dir() / name
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def parse_time(value: str) -> datetime:
    return datetime.fromisoformat(value.replace("Z", "+00:00"))


def within(timestamp: str, start: str, end: str) -> bool:
    ts = parse_time(timestamp)
    return parse_time(start) <= ts <= parse_time(end)


@mcp.tool()
def inventario_fuentes() -> dict[str, Any]:
    """Describe los archivos disponibles y aclara qué campos son observados o inferidos."""
    base = data_dir()
    return {
        "fuentes": [
            {"archivo": "netflow_ipfix.jsonl", "tipo": "IPFIX/NetFlow JSONL", "registros": len(read_jsonl("netflow_ipfix.jsonl"))},
            {"archivo": "nginx_access_combined.log", "tipo": "NGINX Combined extendido", "registros": len((base / "nginx_access_combined.log").read_text().splitlines())},
            {"archivo": "web_access_estructurado.jsonl", "tipo": "Access log normalizado", "registros": len(read_jsonl("web_access_estructurado.jsonl"))},
            {"archivo": "metricas_mcp_observabilidad.csv", "tipo": "Métricas por minuto", "registros": len(pd.read_csv(base / "metricas_mcp_observabilidad.csv"))},
        ],
        "regla_correlacion": "Tiempo + IP de origen + IP/puerto de destino + ruta/servicio.",
        "advertencia": "IPFIX no transporta trace_id en este laboratorio. Los spans de red se marcan lab.inferred_span=true.",
    }


@mcp.tool()
def consultar_netflow(
    inicio: str,
    fin: str,
    ip_origen: str = "",
    puerto_destino: int = 0,
    limite: int = 25,
) -> dict[str, Any]:
    """Consulta flujos IPFIX por ventana UTC, IP y puerto. Fechas ISO 8601, por ejemplo 2026-10-21T14:00:00Z."""
    rows = []
    for flow in read_jsonl("netflow_ipfix.jsonl"):
        ts = datetime.fromtimestamp(flow["flowStartMilliseconds"] / 1000, tz=parse_time(inicio).tzinfo).isoformat()
        if not (parse_time(inicio) <= parse_time(ts) <= parse_time(fin)):
            continue
        if ip_origen and flow["sourceIPv4Address"] != ip_origen:
            continue
        if puerto_destino and flow["destinationTransportPort"] != puerto_destino:
            continue
        rows.append(flow)
    rows = rows[: max(1, min(limite, 100))]
    return {"total_filtrado": len(rows), "resultados": rows}


@mcp.tool()
def consultar_logs_web(
    inicio: str,
    fin: str,
    ruta: str = "",
    estado_minimo: int = 0,
    limite: int = 25,
) -> dict[str, Any]:
    """Consulta access logs web normalizados por tiempo, ruta y código HTTP mínimo."""
    rows = []
    for log in read_jsonl("web_access_estructurado.jsonl"):
        if not within(log["timestamp"], inicio, fin):
            continue
        if ruta and ruta not in log["url_path"]:
            continue
        if estado_minimo and log["status"] < estado_minimo:
            continue
        rows.append(log)
    rows.sort(key=lambda x: (x["status"], x["request_time"]), reverse=True)
    rows = rows[: max(1, min(limite, 100))]
    return {"total_filtrado": len(rows), "resultados": rows}


@mcp.tool()
def resumir_ventana(inicio: str, fin: str) -> dict[str, Any]:
    """Calcula un resumen conjunto de métricas, flujos y solicitudes web para una ventana UTC."""
    df = pd.read_csv(data_dir() / "metricas_mcp_observabilidad.csv", parse_dates=["timestamp"])
    start, end = pd.Timestamp(inicio), pd.Timestamp(fin)
    cut = df[(df.timestamp >= start) & (df.timestamp <= end)]
    if cut.empty:
        return {"error": "La ventana no contiene métricas."}
    web = [x for x in read_jsonl("web_access_estructurado.jsonl") if within(x["timestamp"], inicio, fin)]
    flows = []
    for x in read_jsonl("netflow_ipfix.jsonl"):
        ts = pd.to_datetime(x["flowStartMilliseconds"], unit="ms", utc=True)
        if start <= ts <= end:
            flows.append(x)
    return {
        "ventana": {"inicio": inicio, "fin": fin, "minutos": len(cut)},
        "metricas": {
            "link_utilization_pct_mean": round(float(cut.link_utilization_pct.mean()), 3),
            "link_utilization_pct_max": round(float(cut.link_utilization_pct.max()), 3),
            "tcp_retransmissions_pct_mean": round(float(cut.tcp_retransmissions_pct.mean()), 3),
            "web_latency_p95_ms_mean": round(float(cut.web_latency_p95_ms.mean()), 3),
            "http_error_pct_mean": round(float(cut.http_error_pct.mean()), 3),
            "active_connections_mean": round(float(cut.active_connections.mean()), 3),
            "report_rps_mean": round(float(cut.report_rps.mean()), 3),
        },
        "web": {
            "solicitudes": len(web),
            "errores_5xx": sum(x["status"] >= 500 for x in web),
            "ruta_mayor_volumen": max(web, key=lambda x: x["body_bytes_sent"])["url_path"] if web else None,
            "bytes_respuesta": sum(x["body_bytes_sent"] for x in web),
        },
        "red": {
            "flujos": len(flows),
            "octetos": sum(x["octetDeltaCount"] for x in flows),
            "principal_ip_origen": max(flows, key=lambda x: x["octetDeltaCount"])["sourceIPv4Address"] if flows else None,
        },
    }


@mcp.tool()
def correlacionar_incidente(inicio: str, fin: str) -> dict[str, Any]:
    """Correlaciona NetFlow y access logs, separando hechos, inferencias e información faltante."""
    summary = resumir_ventana(inicio, fin)
    if "error" in summary:
        return summary
    errors = consultar_logs_web(inicio, fin, estado_minimo=500, limite=10)["resultados"]
    reports = consultar_logs_web(inicio, fin, ruta="/api/reports", limite=10)["resultados"]
    return {
        "hechos_observados": [
            f"Utilización media del enlace: {summary['metricas']['link_utilization_pct_mean']}%.",
            f"Retransmisiones TCP medias: {summary['metricas']['tcp_retransmissions_pct_mean']}%.",
            f"Latencia web p95 media: {summary['metricas']['web_latency_p95_ms_mean']} ms.",
            f"Errores web 5xx encontrados: {summary['web']['errores_5xx']}.",
            f"La ruta de mayor volumen es {summary['web']['ruta_mayor_volumen']}.",
        ],
        "correlaciones": [
            "El aumento de /api/reports/export coincide con utilización alta del enlace.",
            "Los errores 503/504 coinciden con retransmisiones y conexiones activas elevadas.",
        ],
        "hipotesis_candidatas": [
            {"id": "H1", "texto": "Las respuestas grandes de reportes saturaron el enlace compartido.", "prioridad": 1},
            {"id": "H2", "texto": "El servidor web agotó recursos antes de que se degradara la red.", "prioridad": 2},
            {"id": "H3", "texto": "Un fallo externo independiente causó los 5xx.", "prioridad": 3},
        ],
        "muestras": {"errores_web": errors[:3], "reportes": reports[:3]},
        "informacion_faltante": [
            "CPU y memoria del servidor web", "métricas de cola del upstream", "captura de paquetes o RTT real",
        ],
    }


@mcp.tool()
def obtener_evidencia_traza(trace_id: str) -> dict[str, Any]:
    """Obtiene la solicitud web, la traza Jaeger y el flujo temporalmente relacionado con un trace_id."""
    web = next((x for x in read_jsonl("web_access_estructurado.jsonl") if x["trace_id"] == trace_id), None)
    if not web:
        return {"error": "trace_id no encontrado"}
    jaeger = json.loads((data_dir() / "trazas_mcp_jaeger.json").read_text(encoding="utf-8"))
    trace = next((x for x in jaeger["data"] if x["traceID"] == trace_id), None)
    request_ts = parse_time(web["timestamp"])
    candidate = None
    best_delta = float("inf")
    for flow in read_jsonl("netflow_ipfix.jsonl"):
        flow_ts = datetime.fromtimestamp(flow["flowStartMilliseconds"] / 1000, tz=request_ts.tzinfo)
        delta = abs((request_ts - flow_ts).total_seconds())
        if flow["sourceIPv4Address"] == web["remote_addr"] and delta < best_delta:
            candidate, best_delta = flow, delta
    return {
        "web_log": web,
        "flujo_correlacionado": candidate,
        "diferencia_temporal_segundos": round(best_delta, 3),
        "traza": trace,
        "advertencia": "El span de red es inferido por correlación; no fue emitido por NetFlow con un trace_id.",
    }


@mcp.tool()
def preparar_contexto_llm(inicio: str, fin: str) -> dict[str, Any]:
    """Prepara evidencia compacta y trazable para que un LLM genere hipótesis sin recibir todos los logs."""
    baseline = resumir_ventana("2026-10-21T13:00:00Z", "2026-10-21T13:44:00Z")
    incident = resumir_ventana(inicio, fin)
    correlation = correlacionar_incidente(inicio, fin)
    return {
        "pregunta": "¿Cuál es la causa más probable de la degradación y cómo podría comprobarse?",
        "linea_base": baseline,
        "ventana_investigada": incident,
        "evidencia_correlacionada": correlation,
        "instrucciones_llm": [
            "Separar hechos, inferencias e hipótesis.",
            "No afirmar causalidad solo por correlación.",
            "Citar valores y fuentes del contexto.",
            "Proponer una prueba que pueda refutar la hipótesis principal.",
        ],
    }


if __name__ == "__main__":
    mcp.run(transport="stdio")
