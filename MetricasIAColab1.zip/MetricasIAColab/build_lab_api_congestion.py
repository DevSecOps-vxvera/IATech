from __future__ import annotations

import csv
import hashlib
import json
import math
import random
import textwrap
import zipfile
from datetime import datetime, timedelta, timezone
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.ensemble import IsolationForest
from sklearn.metrics import precision_recall_fscore_support
from sklearn.neighbors import LocalOutlierFactor
from sklearn.preprocessing import RobustScaler
from statsmodels.tsa.seasonal import STL


ROOT = Path(__file__).resolve().parent
OUT = ROOT / "lab_api_red_congestionada"
OUT.mkdir(exist_ok=True)
RNG = np.random.default_rng(42)
random.seed(42)

FEATURES = [
    "api_requests_per_sec",
    "api_latency_p95_ms",
    "http_error_rate_pct",
    "timeout_rate_pct",
    "retry_rate_pct",
    "network_rtt_ms",
    "packet_loss_pct",
    "link_utilization_pct",
]


def make_telemetry() -> pd.DataFrame:
    n = 3 * 24 * 60
    ts = pd.date_range("2026-10-18T00:00:00Z", periods=n, freq="min")
    minute = np.arange(n)
    tod = minute % 1440
    business = np.exp(-((tod - 810) / 330) ** 2)
    wave = np.sin(2 * np.pi * tod / 1440)

    rps = 44 + 31 * business + 4 * wave + RNG.normal(0, 2.5, n)
    util = 27 + 0.62 * rps + RNG.normal(0, 2.2, n)
    rtt = 18 + 0.11 * util + RNG.normal(0, 1.4, n)
    loss = np.clip(RNG.normal(0.08, 0.05, n), 0, None)
    retry = np.clip(0.35 + 0.018 * util + RNG.normal(0, 0.18, n), 0, None)
    timeout = np.clip(0.05 + 0.006 * util + RNG.normal(0, 0.08, n), 0, None)
    errors = np.clip(0.25 + 0.012 * util + RNG.normal(0, 0.12, n), 0, None)
    latency = 105 + 1.35 * rtt + 0.32 * util + RNG.normal(0, 7.5, n)

    incident = np.zeros(n, dtype=int)
    incident_id = np.array([""] * n, dtype=object)
    scenario = np.array(["normal"] * n, dtype=object)
    cause = np.array([""] * n, dtype=object)

    # Incidente principal: sincronización masiva comparte un enlace de 100 Mbps.
    start, end = 2 * 1440 + 12 * 60 + 20, 2 * 1440 + 13 * 60 + 36
    idx = np.arange(start, end)
    phase = np.linspace(0, np.pi, len(idx))
    util[idx] = np.clip(95.5 + 3.0 * np.sin(phase) + RNG.normal(0, 0.8, len(idx)), 93, 99.8)
    rtt[idx] += 95 + 120 * np.sin(phase) + RNG.normal(0, 8, len(idx))
    loss[idx] += 2.8 + 4.5 * np.sin(phase) + RNG.normal(0, 0.35, len(idx))
    retry[idx] += 8 + 14 * np.sin(phase) + RNG.normal(0, 0.7, len(idx))
    timeout[idx] += 3 + 10 * np.sin(phase) + RNG.normal(0, 0.45, len(idx))
    errors[idx] += 4 + 13 * np.sin(phase) + RNG.normal(0, 0.55, len(idx))
    latency[idx] += 420 + 1250 * np.sin(phase) + RNG.normal(0, 45, len(idx))
    rps[idx] += 18 + 8 * np.sin(phase)
    incident[idx] = 1
    incident_id[idx] = "INC-API-NET-001"
    scenario[idx] = "congestion_canal_por_sincronizacion_masiva"
    cause[idx] = "Saturacion del enlace compartido; aumenta cola, RTT, perdida, reintentos y 504"

    # Anomalías cortas fuera del incidente: útiles para discutir falsos positivos/localidad.
    for center in [520, 1790, 2485]:
        local = np.arange(center, center + 7)
        latency[local] += RNG.normal(220, 25, len(local))
        errors[local] += RNG.normal(2.2, 0.25, len(local))
        scenario[local] = "degradacion_api_breve"

    success = np.maximum(rps * (1 - np.clip(errors + timeout, 0, 95) / 100), 0)
    df = pd.DataFrame({
        "timestamp": ts,
        "api_requests_per_sec": np.round(rps, 2),
        "api_throughput_success_rps": np.round(success, 2),
        "api_latency_p95_ms": np.round(latency, 2),
        "http_error_rate_pct": np.round(errors, 3),
        "timeout_rate_pct": np.round(timeout, 3),
        "retry_rate_pct": np.round(retry, 3),
        "network_rtt_ms": np.round(rtt, 2),
        "packet_loss_pct": np.round(np.clip(loss, 0, 100), 3),
        "link_utilization_pct": np.round(np.clip(util, 0, 100), 2),
        "is_incident": incident,
        "incident_id": incident_id,
        "scenario": scenario,
        "probable_cause": cause,
    })
    return df


def rolling_mad_flags(series: pd.Series, window: int = 180, threshold: float = 5.0):
    med = series.rolling(window, min_periods=60).median()
    mad = (series - med).abs().rolling(window, min_periods=60).median()
    robust_z = 0.6745 * (series - med).abs() / mad.replace(0, np.nan)
    robust_z = robust_z.fillna(0)
    return robust_z, (robust_z > threshold).astype(int)


def detect(df: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    out = df.copy()
    z_latency, f_latency = rolling_mad_flags(out["api_latency_p95_ms"])
    z_util, f_util = rolling_mad_flags(out["link_utilization_pct"])
    out["mad_score"] = np.maximum(z_latency, z_util)
    out["mad_anomaly"] = ((f_latency == 1) | (f_util == 1)).astype(int)

    stl = STL(out["api_latency_p95_ms"], period=1440, robust=True).fit()
    out["stl_trend"] = stl.trend
    out["stl_seasonal"] = stl.seasonal
    out["stl_resid"] = stl.resid
    resid_med = np.median(stl.resid)
    resid_mad = np.median(np.abs(stl.resid - resid_med)) or 1e-9
    out["stl_score"] = 0.6745 * np.abs(stl.resid - resid_med) / resid_mad
    out["stl_anomaly"] = (out["stl_score"] > 5.0).astype(int)

    X = RobustScaler().fit_transform(out[FEATURES])
    iso = IsolationForest(n_estimators=250, contamination=0.03, random_state=42)
    out["isolation_forest_anomaly"] = (iso.fit_predict(X) == -1).astype(int)
    out["isolation_forest_score"] = -iso.score_samples(X)
    lof = LocalOutlierFactor(n_neighbors=35, contamination=0.03)
    out["lof_anomaly"] = (lof.fit_predict(X) == -1).astype(int)
    out["lof_score"] = -lof.negative_outlier_factor_

    rows = []
    for name, col in [
        ("Mediana+MAD", "mad_anomaly"),
        ("STL+residuo", "stl_anomaly"),
        ("Isolation Forest", "isolation_forest_anomaly"),
        ("LOF", "lof_anomaly"),
    ]:
        p, r, f1, _ = precision_recall_fscore_support(
            out["is_incident"], out[col], average="binary", zero_division=0
        )
        tp = int(((out[col] == 1) & (out.is_incident == 1)).sum())
        fp = int(((out[col] == 1) & (out.is_incident == 0)).sum())
        fn = int(((out[col] == 0) & (out.is_incident == 1)).sum())
        rows.append({"metodo": name, "alertas": int(out[col].sum()), "TP": tp, "FP": fp, "FN": fn,
                     "precision": round(p, 3), "recall": round(r, 3), "F1": round(f1, 3)})
    return out, pd.DataFrame(rows)


def h(value):
    if isinstance(value, bool): return {"boolValue": value}
    if isinstance(value, (int, np.integer)): return {"intValue": str(int(value))}
    if isinstance(value, (float, np.floating)): return {"doubleValue": round(float(value), 6)}
    return {"stringValue": str(value)}


def attrs_otel(d):
    return [{"key": str(k), "value": h(v)} for k, v in d.items()]


def tag_type_value(v):
    if isinstance(v, bool): return "bool", v
    if isinstance(v, (int, np.integer)): return "int64", int(v)
    if isinstance(v, (float, np.floating)): return "float64", float(v)
    return "string", str(v)


def tags_jaeger(d):
    out = []
    for k, v in d.items():
        typ, value = tag_type_value(v)
        out.append({"key": str(k), "type": typ, "value": value})
    return out


def make_traces(df: pd.DataFrame):
    incident = df[df.is_incident == 1]
    selections = np.linspace(0, len(incident) - 1, 12).round().astype(int)
    rows = incident.iloc[selections]
    services = ["client-app", "api-gateway", "auth-service", "orders-api", "partner-api", "network-observer", "aiops-analyzer"]
    jaeger_traces = []
    otel_by_service = {s: [] for s in services}

    for seq, (_, row) in enumerate(rows.iterrows(), 1):
        seed = f"INC-API-NET-001-{seq}-{row.timestamp}"
        trace_id = hashlib.md5(seed.encode()).hexdigest()
        base_ns = int(pd.Timestamp(row.timestamp).value)
        base_us = base_ns // 1000
        total_ms = max(float(row.api_latency_p95_ms), 100)
        status_code = 504 if row.timeout_rate_pct > 5 else (429 if row.retry_rate_pct > 10 else 200)
        common = {
            "incident.id": "INC-API-NET-001",
            "lab.trace.sequence": seq,
            "api.requests_per_sec": float(row.api_requests_per_sec),
            "api.latency.p95_ms": float(row.api_latency_p95_ms),
            "http.error_rate_pct": float(row.http_error_rate_pct),
            "http.timeout_rate_pct": float(row.timeout_rate_pct),
            "http.retry_rate_pct": float(row.retry_rate_pct),
            "network.rtt_ms": float(row.network_rtt_ms),
            "network.packet_loss_pct": float(row.packet_loss_pct),
            "network.link.utilization_pct": float(row.link_utilization_pct),
            "detector.mad.anomaly": bool(row.mad_anomaly),
            "detector.stl.anomaly": bool(row.stl_anomaly),
            "detector.isolation_forest.anomaly": bool(row.isolation_forest_anomaly),
            "detector.lof.anomaly": bool(row.lof_anomaly),
        }
        specs = [
            ("client-app", "HTTP GET /orders", 0.00, 1.00, {}),
            ("api-gateway", "gateway.route /orders", 0.03, 0.94, {"http.status_code": status_code}),
            ("auth-service", "auth.validate", 0.08, 0.18, {}),
            ("orders-api", "orders.fetch", 0.22, 0.83, {}),
            ("partner-api", "partner.inventory", 0.34, 0.75, {"peer.service": "partner-api"}),
            ("network-observer", "network.observe shared-channel", 0.05, 0.90, {"network.channel": "WAN-100Mbps"}),
            ("aiops-analyzer", "aiops.detect-and-rank", 0.91, 0.99, {"aiops.probable_cause": "shared_link_congestion", "aiops.confidence": "high"}),
        ]
        span_ids = [hashlib.sha256(f"{seed}-{i}".encode()).hexdigest()[:16] for i in range(len(specs))]
        j_spans = []
        for i, (service, operation, start_frac, end_frac, extra) in enumerate(specs):
            sid = span_ids[i]
            parent = "" if i == 0 else span_ids[0]
            dur_us = max(1000, int(total_ms * (end_frac - start_frac) * 1000))
            start_us = base_us + int(total_ms * start_frac * 1000)
            attributes = {**common, **extra, "service.role": service}
            if i == 0:
                attributes.update({"http.request.method": "GET", "url.path": "/orders", "http.response.status_code": status_code})
            status_error = status_code >= 400 and i in (0, 1, 3, 4)
            j_spans.append({
                "traceID": trace_id,
                "spanID": sid,
                "flags": 1,
                "operationName": operation,
                "references": [] if i == 0 else [{"refType": "CHILD_OF", "traceID": trace_id, "spanID": parent}],
                "startTime": start_us,
                "duration": dur_us,
                "tags": tags_jaeger({**attributes, "otel.status_code": "ERROR" if status_error else "OK", "error": status_error}),
                "logs": [{"timestamp": start_us + dur_us - 1, "fields": tags_jaeger({"event": "timeout_upstream", "message": "Respuesta excede el limite por cola de red"})}] if status_error else [],
                "processID": f"p{i+1}",
                "warnings": None,
            })
            start_ns = start_us * 1000
            end_ns = (start_us + dur_us) * 1000
            otel_span = {
                "traceId": trace_id,
                "spanId": sid,
                "name": operation,
                "kind": "SPAN_KIND_CLIENT" if i in (0, 4) else "SPAN_KIND_SERVER",
                "startTimeUnixNano": str(start_ns),
                "endTimeUnixNano": str(end_ns),
                "attributes": attrs_otel(attributes),
                "status": {"code": "STATUS_CODE_ERROR" if status_error else "STATUS_CODE_OK", "message": "upstream timeout" if status_error else ""},
            }
            if parent: otel_span["parentSpanId"] = parent
            if status_error:
                otel_span["events"] = [{"timeUnixNano": str(end_ns - 1000), "name": "timeout_upstream", "attributes": attrs_otel({"message": "Respuesta excede el limite por cola de red"})}]
            otel_by_service[service].append(otel_span)

        processes = {f"p{i+1}": {"serviceName": s, "tags": tags_jaeger({"service.version": "1.0.0", "deployment.environment": "lab-colab"})} for i, s in enumerate(services)}
        jaeger_traces.append({"traceID": trace_id, "spans": j_spans, "processes": processes, "warnings": None})

    otlp = {"resourceSpans": []}
    for service, spans in otel_by_service.items():
        otlp["resourceSpans"].append({
            "resource": {"attributes": attrs_otel({"service.name": service, "service.version": "1.0.0", "deployment.environment": "lab-colab"})},
            "scopeSpans": [{"scope": {"name": "edu.observability.api-network-lab", "version": "1.0.0"}, "spans": spans}],
        })
    jaeger = {"data": jaeger_traces, "total": len(jaeger_traces), "limit": 0, "offset": 0, "errors": None}
    return jaeger, otlp


def md_cell(text):
    return {"cell_type": "markdown", "metadata": {}, "source": textwrap.dedent(text).strip().splitlines(True)}


def code_cell(code):
    return {"cell_type": "code", "execution_count": None, "metadata": {}, "outputs": [], "source": textwrap.dedent(code).strip().splitlines(True)}


def make_notebook():
    cells = [
        md_cell("""
        # Laboratorio: AIOps para consumo de API sobre un canal congestionado

        **Duración sugerida:** 3–4 horas. **Entorno:** Google Colab (CPU suficiente).

        Se analizarán ocho métricas de API y red con cuatro técnicas: Mediana+MAD, STL+residuo, Isolation Forest y LOF. El laboratorio genera dos archivos de trazas equivalentes: `trazas_api_red_congestionada_otel.json` (OTLP/JSON) y `trazas_api_red_congestionada_jaeger.json` (importación visual de Jaeger).

        > Regla didáctica: primero evidencia, después hipótesis. Una salida del LLM no demuestra causalidad.
        """),
        md_cell("""
        ## 0. Preparar Colab

        Ejecute la celda. Si subió el ZIP, descomprímalo antes; si subió los archivos sueltos, continúe. `statsmodels` implementa STL y `transformers` permite ejecutar un modelo pequeño al final.
        """),
        code_cell("""
        %pip -q install statsmodels transformers sentencepiece
        import json, os, zipfile, warnings
        import numpy as np
        import pandas as pd
        import matplotlib.pyplot as plt
        import seaborn as sns
        from IPython.display import display
        from sklearn.preprocessing import RobustScaler
        from sklearn.ensemble import IsolationForest
        from sklearn.neighbors import LocalOutlierFactor
        from sklearn.metrics import precision_recall_fscore_support
        from statsmodels.tsa.seasonal import STL
        warnings.filterwarnings('ignore')
        sns.set_theme(style='whitegrid')
        print('Entorno preparado.')
        """),
        md_cell("""
        ## 1. Cargar y reconocer las métricas

        Cada fila representa un minuto. Las métricas no dicen lo mismo: RPS mide demanda; throughput exitoso, trabajo útil; p95, experiencia de la cola lenta; errores/timeouts/reintentos, síntomas de aplicación; RTT/pérdida/utilización, estado del canal.
        """),
        code_cell("""
        CSV = 'telemetria_api_red_congestionada.csv'
        if not os.path.exists(CSV):
            from google.colab import files
            print('Suba telemetria_api_red_congestionada.csv')
            files.upload()
        df = pd.read_csv(CSV, parse_dates=['timestamp'])
        metricas = ['api_requests_per_sec','api_throughput_success_rps','api_latency_p95_ms',
                    'http_error_rate_pct','timeout_rate_pct','retry_rate_pct','network_rtt_ms',
                    'packet_loss_pct','link_utilization_pct']
        print(df.shape, df.timestamp.min(), df.timestamp.max())
        display(df[metricas].describe().T.round(2))
        """),
        md_cell("""
        ### Lectura esperada

        - La utilización cercana a 100 % indica falta de margen, pero no prueba por sí sola que exista impacto.
        - Si a la vez suben RTT, pérdida y reintentos, existe evidencia de colas y retransmisiones.
        - Si después suben p95, timeouts y HTTP 504, aparece el efecto sobre la API.
        - Compare RPS solicitado con throughput exitoso: más demanda no necesariamente significa más trabajo completado.
        """),
        code_cell("""
        fig, axes = plt.subplots(5, 2, figsize=(17, 18), sharex=True)
        for ax, m in zip(axes.flat, metricas):
            ax.plot(df.timestamp, df[m], lw=.8)
            ax.fill_between(df.timestamp, 0, df[m].max(), where=df.is_incident.eq(1), alpha=.12, color='red')
            ax.set_title(m); ax.set_ylabel(m)
        axes.flat[-1].axis('off')
        plt.tight_layout(); plt.show()
        """),
        md_cell("""
        ## 2. Mediana y MAD: anomalías robustas y explicables

        La mediana móvil estima la línea base. `MAD = mediana(|x - mediana(x)|)`. El puntaje robusto es `0.6745 × |x−mediana| / MAD`. El umbral 5 es deliberadamente conservador. MAD resiste picos mejor que media/desviación estándar; si MAD es cero se evita dividir por cero.
        """),
        code_cell("""
        def rolling_mad(s, window=180, threshold=5):
            med = s.rolling(window, min_periods=60).median()
            mad = (s-med).abs().rolling(window, min_periods=60).median()
            score = (0.6745*(s-med).abs()/mad.replace(0,np.nan)).fillna(0)
            return med, mad, score, score.gt(threshold).astype(int)
        _, _, zlat, flat = rolling_mad(df.api_latency_p95_ms)
        _, _, zutil, futil = rolling_mad(df.link_utilization_pct)
        df['mad_score'] = np.maximum(zlat,zutil)
        df['mad_anomaly'] = ((flat==1)|(futil==1)).astype(int)
        print('Alertas MAD:', int(df.mad_anomaly.sum()))
        display(df.nlargest(10,'mad_score')[['timestamp','api_latency_p95_ms','link_utilization_pct','mad_score','is_incident']])
        """),
        md_cell("""
        **Interpretación:** un puntaje MAD alto responde “¿cuán lejos está este minuto de su línea base robusta reciente?”. Es un detector univariado: explica bien el salto, pero no modela por sí mismo la relación entre red y API.
        """),
        md_cell("""
        ## 3. STL y residuo: separar ciclo diario de comportamiento inesperado

        STL descompone `observado = tendencia + estacionalidad + residuo`. Se usa período 1440 porque los datos son por minuto y hay un ciclo diario. Una anomalía se busca en el residuo, no en el tráfico alto que es normal cada día.
        """),
        code_cell("""
        fit = STL(df.api_latency_p95_ms, period=1440, robust=True).fit()
        df['stl_trend'], df['stl_seasonal'], df['stl_resid'] = fit.trend, fit.seasonal, fit.resid
        med = np.median(fit.resid); mad = np.median(np.abs(fit.resid-med)) or 1e-9
        df['stl_score'] = 0.6745*np.abs(fit.resid-med)/mad
        df['stl_anomaly'] = df.stl_score.gt(5).astype(int)
        fig = fit.plot(); fig.set_size_inches(16,10); plt.show()
        print('Alertas STL:', int(df.stl_anomaly.sum()))
        """),
        md_cell("""
        **Interpretación:** un residuo grande significa que la latencia no se explica por la tendencia ni por el patrón diario. STL necesita varios ciclos y una frecuencia correcta; con solo unas horas, el resultado sería frágil.
        """),
        md_cell("""
        ## 4. Isolation Forest: rareza multivariable

        Aísla rápidamente observaciones poco comunes. Usaremos todas las métricas y 3 % de contaminación esperada. No requiere etiquetas para entrenar, pero sí contexto para interpretar el resultado.
        """),
        code_cell("""
        features = ['api_requests_per_sec','api_latency_p95_ms','http_error_rate_pct','timeout_rate_pct',
                    'retry_rate_pct','network_rtt_ms','packet_loss_pct','link_utilization_pct']
        X = RobustScaler().fit_transform(df[features])
        iso = IsolationForest(n_estimators=250, contamination=.03, random_state=42)
        df['isolation_forest_anomaly'] = (iso.fit_predict(X)==-1).astype(int)
        df['isolation_forest_score'] = -iso.score_samples(X)
        display(df.nlargest(10,'isolation_forest_score')[['timestamp']+features+['is_incident']])
        """),
        md_cell("""
        **Interpretación:** el método detecta combinaciones raras, por ejemplo utilización+RTT+pérdida+timeouts simultáneamente. El 3 % es una expectativa operativa, no una verdad; cambiarlo cambia cuántas alertas aparecen.
        """),
        md_cell("""
        ## 5. LOF: rareza respecto de vecinos locales

        LOF compara la densidad de cada punto con la de sus 35 vecinos. Es útil cuando existen grupos normales distintos (noche, hora pico) y una comparación global sería injusta.
        """),
        code_cell("""
        lof = LocalOutlierFactor(n_neighbors=35, contamination=.03)
        df['lof_anomaly'] = (lof.fit_predict(X)==-1).astype(int)
        df['lof_score'] = -lof.negative_outlier_factor_
        display(df.nlargest(10,'lof_score')[['timestamp']+features+['is_incident']])
        """),
        md_cell("""
        **Interpretación:** LOF pregunta “¿este minuto es extraño frente a minutos parecidos?”. Puede detectar anomalías locales, pero es sensible al número de vecinos, a la escala y a cambios de densidad.
        """),
        md_cell("""
        ## 6. Comparar los detectores con la verdad de laboratorio

        `precision = TP/(TP+FP)` responde qué proporción de alertas fue correcta. `recall = TP/(TP+FN)` responde qué proporción del incidente detectamos. F1 equilibra ambas. En producción no suele existir una etiqueta perfecta; aquí se incluye para aprender.
        """),
        code_cell("""
        rows=[]
        for name,col in [('Mediana+MAD','mad_anomaly'),('STL+residuo','stl_anomaly'),
                         ('Isolation Forest','isolation_forest_anomaly'),('LOF','lof_anomaly')]:
            p,r,f1,_=precision_recall_fscore_support(df.is_incident,df[col],average='binary',zero_division=0)
            tp=((df[col]==1)&(df.is_incident==1)).sum(); fp=((df[col]==1)&(df.is_incident==0)).sum(); fn=((df[col]==0)&(df.is_incident==1)).sum()
            rows.append([name,int(df[col].sum()),int(tp),int(fp),int(fn),p,r,f1])
        resultados=pd.DataFrame(rows,columns=['metodo','alertas','TP','FP','FN','precision','recall','F1'])
        display(resultados.round(3))
        resultados.set_index('metodo')[['precision','recall','F1']].plot.bar(figsize=(10,5),ylim=(0,1)); plt.show()
        """),
        md_cell("""
        ### Resultado esperado y por qué no “ganan” todos

        En estos datos, MAD e Isolation Forest logran recall alto. STL puede absorber una degradación sostenida dentro de la tendencia y LOF puede considerar que muchos minutos consecutivos del incidente forman un grupo local denso; por eso ambos pueden mostrar recall bajo. No es un error del cuaderno: demuestra que un detector depende de la forma y duración del incidente. Compare los números con `resultados_esperados.csv` y explique los falsos negativos.
        """),
        code_cell("""
        fig, axes=plt.subplots(4,1,figsize=(17,12),sharex=True)
        for ax,(nombre,col,color) in zip(axes,[('MAD','mad_anomaly','tab:red'),('STL','stl_anomaly','tab:orange'),
                 ('Isolation Forest','isolation_forest_anomaly','tab:purple'),('LOF','lof_anomaly','tab:green')]):
            ax.plot(df.timestamp,df.api_latency_p95_ms,lw=.7,color='steelblue')
            sel=df[col].eq(1)
            ax.scatter(df.loc[sel,'timestamp'],df.loc[sel,'api_latency_p95_ms'],s=12,color=color,label='alerta')
            ax.set_title(nombre); ax.legend(loc='upper left')
        plt.tight_layout(); plt.show()
        """),
        md_cell("""
        ## 7. Correlación temporal y cadena causal

        Busque el orden: saturación → cola/RTT → pérdida/reintentos → latencia/timeouts/errores → caída del throughput exitoso. La correlación apoya una hipótesis; no sustituye una prueba controlada.
        """),
        code_cell("""
        inc=df[df.is_incident.eq(1)]
        display(inc[features+['api_throughput_success_rps']].corr().round(2).style.background_gradient(cmap='RdBu_r',vmin=-1,vmax=1))
        resumen = {
          'ventana': [str(inc.timestamp.min()), str(inc.timestamp.max())],
          'utilizacion_max_pct': round(inc.link_utilization_pct.max(),2),
          'rtt_max_ms': round(inc.network_rtt_ms.max(),2),
          'perdida_max_pct': round(inc.packet_loss_pct.max(),2),
          'latencia_p95_max_ms': round(inc.api_latency_p95_ms.max(),2),
          'timeouts_max_pct': round(inc.timeout_rate_pct.max(),2),
          'errores_http_max_pct': round(inc.http_error_rate_pct.max(),2),
          'hipotesis_guiada': 'Congestion del enlace compartido por sincronizacion masiva'
        }
        print(json.dumps(resumen,indent=2,ensure_ascii=False))
        """),
        md_cell("""
        ## 8. Inspeccionar y descargar las trazas

        El archivo OTLP conserva el modelo OpenTelemetry. El archivo Jaeger está adaptado al importador visual de la demo. Ambos contienen 12 trazas y 84 spans del mismo incidente. El paquete también incluye `build_lab_api_congestion.py`: al ejecutarlo vuelve a generar desde cero el CSV, ambos JSON, los resultados y el ZIP, por lo que el proceso es reproducible.
        """),
        code_cell("""
        with open('trazas_api_red_congestionada_otel.json',encoding='utf-8') as f: otlp=json.load(f)
        with open('trazas_api_red_congestionada_jaeger.json',encoding='utf-8') as f: jaeger=json.load(f)
        n_otel=sum(len(ss.get('spans',[])) for rs in otlp['resourceSpans'] for ss in rs.get('scopeSpans',[]))
        n_j=sum(len(t['spans']) for t in jaeger['data'])
        print('OTLP resourceSpans:',len(otlp['resourceSpans']),'spans:',n_otel)
        print('Jaeger traces:',len(jaeger['data']),'spans:',n_j)
        assert n_otel==n_j==84 and len(jaeger['data'])==12
        """),
        md_cell("""
        ### Importación en Jaeger Demo

        1. Abra `https://demo.jaegertracing.io/jaeger/`.
        2. Seleccione **Upload JSON** (icono/carga disponible en la interfaz).
        3. Cargue **`trazas_api_red_congestionada_jaeger.json`**, no el OTLP.
        4. Abra una traza y expanda `network.observe shared-channel` y `aiops.detect-and-rank`.
        5. Verifique `network.link.utilization_pct`, `network.rtt_ms`, `network.packet_loss_pct`, `http.timeout_rate_pct` y los flags de detectores.

        La carga es temporal en su navegador; no equivale a enviar OTLP a un collector persistente.
        """),
        md_cell("""
        ## 9. LLM mínimo local: revisar evidencia y proponer hipótesis

        FLAN-T5-small es un modelo pequeño de instrucciones. Para respetar su ventana de contexto no se envía todo el archivo: primero se extrae un resumen compacto de una traza. El modelo debe citar atributos presentes y separar evidencia, hipótesis y pruebas propuestas.
        """),
        code_cell("""
        trace=jaeger['data'][6]
        def tagmap(span): return {t['key']:t['value'] for t in span.get('tags',[])}
        evidencia=[]
        for s in trace['spans']:
            t=tagmap(s)
            evidencia.append({'servicio':trace['processes'][s['processID']]['serviceName'],'operacion':s['operationName'],
              'duracion_ms':round(s['duration']/1000,1),
              'status':t.get('otel.status_code'),'http':t.get('http.status_code',t.get('http.response.status_code')),
              'util_pct':t.get('network.link.utilization_pct'),'rtt_ms':t.get('network.rtt_ms'),
              'perdida_pct':t.get('network.packet_loss_pct'),'reintentos_pct':t.get('http.retry_rate_pct'),
              'timeouts_pct':t.get('http.timeout_rate_pct')})
        print(json.dumps(evidencia,ensure_ascii=False,indent=2))
        """),
        code_cell("""
        from transformers import pipeline
        try:
            llm=pipeline('text2text-generation',model='google/flan-t5-small',device=-1)
            prompt = ('Analiza la evidencia JSON de una traza de API. Responde en español y de forma breve con:'
                      + chr(10) + '1) hechos observados,' + chr(10) + '2) tres hipótesis ordenadas,'
                      + chr(10) + '3) evidencia a favor y en contra,' + chr(10) + '4) siguiente prueba no destructiva,'
                      + chr(10) + '5) confianza baja/media/alta.' + chr(10)
                      + 'No inventes valores. Si falta evidencia, dilo.' + chr(10) + 'EVIDENCIA:' + chr(10)
                      + json.dumps(evidencia,ensure_ascii=False))
            salida=llm(prompt,max_new_tokens=280,do_sample=False)[0]['generated_text']
            print(salida)
        except Exception as e:
            print('No fue posible cargar el modelo:',e)
            print('Hipótesis guiada: congestión del canal; valide la secuencia util→RTT/pérdida→reintentos→timeout/504.')
        """),
        md_cell("""
        ### Prompts de seguimiento

        - “Compara estas tres hipótesis: congestión del enlace, defecto del API y lentitud del proveedor. Para cada una, lista evidencia a favor, evidencia faltante y una prueba segura.”
        - “No generes diagnóstico. Extrae solamente valores observables, servicio, operación, duración, estado y orden temporal.”
        - “Actúa como revisor escéptico: busca una explicación alternativa que contradiga la hipótesis principal.”
        - “Redacta un informe de incidente con impacto, línea temporal, causa probable, nivel de confianza y acciones; separa hechos de inferencias.”

        **Cierre:** entregue tabla de detectores, captura de Jaeger, evidencia, hipótesis principal y alternativa, y una prueba que aumentaría o reduciría la confianza.
        """),
    ]
    return {"cells": cells, "metadata": {"kernelspec": {"display_name": "Python 3", "language": "python", "name": "python3"}, "language_info": {"name": "python", "version": "3.x"}, "colab": {"name": "Laboratorio_API_Red_Congestionada_AIOps_Jaeger_LLM.ipynb", "provenance": []}}, "nbformat": 4, "nbformat_minor": 5}


MANUAL = r"""
# Manual del estudiante

## Laboratorio AIOps: consumo de API sobre un canal congestionado

**Duración:** 3–4 horas  
**Entorno:** Google Colab, navegador y acceso a la demo pública de Jaeger.  
**Pregunta guía:** ¿la degradación se origina en el API, en una dependencia o en el canal de red compartido?

## Resultados de aprendizaje

Al terminar podrá:

1. interpretar métricas de demanda, experiencia, errores y red;
2. aplicar Mediana+MAD, STL, Isolation Forest y LOF;
3. comparar detectores mediante precisión, recall y F1;
4. navegar una traza distribuida y relacionarla con métricas;
5. usar un LLM pequeño para formular hipótesis sin confundirlas con hechos.

## Archivos

| Archivo | Uso |
|---|---|
| `Laboratorio_API_Red_Congestionada_AIOps_Jaeger_LLM.ipynb` | Cuaderno ejecutable en Colab |
| `telemetria_api_red_congestionada.csv` | 4.320 minutos de métricas sintéticas |
| `trazas_api_red_congestionada_otel.json` | Trazas en OTLP/JSON para estudiar OpenTelemetry |
| `trazas_api_red_congestionada_jaeger.json` | 12 trazas/84 spans para **Upload JSON** en Jaeger UI |
| `resultados_esperados.csv` | Referencia de evaluación de detectores |
| `PROMPTS_LLM.md` | Prompts y reglas para análisis asistido |

## Conceptos mínimos

### Métricas del caso

| Métrica | Pregunta que responde | Señal problemática |
|---|---|---|
| RPS solicitados | ¿Cuánta demanda llega? | subida brusca o caída anormal |
| Throughput exitoso | ¿Cuánto trabajo útil termina? | se separa de RPS |
| Latencia p95 | ¿Qué vive el 5 % más lento? | crece antes/durante timeouts |
| Error HTTP | ¿Cuántas respuestas fallan? | 429/5xx crecientes |
| Timeouts | ¿Cuántas solicitudes exceden plazo? | crecimiento junto con RTT |
| Reintentos | ¿Cuánto trabajo se repite? | amplifica congestión |
| RTT | ¿Cuánto tarda ida/vuelta de red? | cola creciente |
| Pérdida | ¿Cuánto tráfico se descarta? | retransmisiones y latencia |
| Utilización | ¿Qué fracción del enlace se ocupa? | >90–95 % sostenido sin margen |

### Técnicas del gráfico

- **Mediana+MAD:** comparación robusta contra una línea base móvil. Fácil de explicar, principalmente univariada.
- **STL+residuo:** separa tendencia y ciclo diario; alerta cuando el residuo es grande.
- **Isolation Forest:** encuentra combinaciones multivariadas globalmente raras.
- **LOF:** encuentra puntos raros respecto de vecinos locales; útil con regímenes noche/día.

## Caso de estudio

Una sincronización masiva comparte un enlace WAN de 100 Mbps con el consumo normal de `/orders`. Entre 12:20 y 13:35 del tercer día, la utilización se aproxima al límite. Se forman colas, suben RTT y pérdida; los clientes reintentan; la demanda efectiva aumenta; aparecen timeouts y respuestas 504. La verdad del laboratorio está en `is_incident`, pero en un caso real debe investigarse.

## Paso a paso

### 1. Abrir el cuaderno

1. Entre a Colab y cargue el `.ipynb`.
2. Suba el CSV y los dos JSON al panel **Files**.
3. Ejecute celdas en orden. Si Colab reinicia el entorno, repita instalación y carga.

**Resultado esperado:** 4.320 filas, tres días, datos por minuto.

### 2. Construir una lectura inicial

Revise `describe()` y los nueve gráficos. Ubique la franja roja del incidente. No formule aún una causa; escriba solo cinco hechos observables.

**Pregunta:** ¿el throughput exitoso crece al mismo ritmo que los RPS durante el incidente?

### 3. Mediana y MAD

MAD significa *desviación absoluta mediana*. Para una ventana móvil:

1. calcule la mediana;
2. calcule las distancias absolutas respecto de esa mediana;
3. tome la mediana de esas distancias;
4. normalice la desviación actual con `0.6745 × |x−mediana|/MAD`.

Un score >5 marca una desviación fuerte. El factor 0.6745 hace comparable el score robusto con un z-score si los datos fueran normales. Si MAD es cero, el cuaderno evita división por cero. Un valor extremo cambia poco la mediana, por eso este método es robusto.

**Resultado que debe explicar:** una alerta MAD dice que latencia o utilización se alejaron de su pasado reciente; no identifica por sí sola la causa.

### 4. STL y residuo

El período 1440 representa un día de minutos. Observe los paneles observado/tendencia/estacional/residuo. Un pico diario predecible puede desaparecer del residuo; la congestión no esperada permanece.

**Resultado que debe explicar:** STL evita confundir hora pico normal con incidente, pero requiere ciclos suficientes y frecuencia correcta.

### 5. Isolation Forest

Se escalan ocho métricas con `RobustScaler`. El bosque aísla rápidamente puntos raros. `contamination=.03` pide aproximadamente 3 % de anomalías.

**Resultado que debe explicar:** una combinación de utilización, RTT, pérdida, retries y timeouts puede ser rara aunque ninguna variable aislada cruce un umbral fijo.

### 6. LOF

LOF compara densidad local con 35 vecinos. Cambie `n_neighbors` a 15 y 60; anote cómo cambian alertas y falsos positivos.

**Resultado que debe explicar:** “raro localmente” no equivale a “raro globalmente”. El ajuste de vecinos depende de densidad y escala temporal.

### 7. Evaluar

Compare precisión, recall y F1. Un falso positivo es una alerta fuera de la ventana etiquetada; un falso negativo es un minuto del incidente no detectado. Discuta el costo operativo: para un canal crítico quizá se tolere más FP a cambio de menos FN.

**Referencia de esta semilla:** MAD e Isolation Forest alcanzan recall 1, mientras STL y LOF presentan recall bajo. La degradación sostenida puede ser absorbida por la tendencia de STL; además, los minutos consecutivos del incidente forman un vecindario denso y LOF deja de verlos como rareza local. El resultado es deliberado: ninguna técnica es universal y una métrica de calidad baja debe explicarse, no ocultarse.

### 8. Formular la cadena de evidencia

Orden recomendado:

1. utilización sostenida cerca del límite;
2. aumento de RTT y pérdida;
3. aumento de reintentos;
4. aumento de latencia p95 y timeouts;
5. errores 504/429 y separación entre RPS y throughput exitoso.

Esto sustenta la hipótesis de congestión. Una prueba adicional sería limitar temporalmente la sincronización en un ambiente controlado y observar si la cadena se revierte.

### 9. Abrir las trazas en Jaeger

1. Abra <https://demo.jaegertracing.io/jaeger/>.
2. Use **Upload JSON**.
3. Seleccione `trazas_api_red_congestionada_jaeger.json`.
4. Abra una traza del centro de la lista.
5. Expanda `network.observe shared-channel` y revise utilización, RTT y pérdida.
6. Expanda `HTTP GET /orders`, `gateway.route /orders` y `partner.inventory`; localice status y timeout.
7. Expanda `aiops.detect-and-rank`; compare los cuatro flags.

**Importante:** no cargue el archivo OTLP directamente en ese botón. El OTLP es el formato de intercambio de OpenTelemetry; este paquete incluye una vista adaptada al modelo aceptado por el cargador visual. La carga de UI es temporal y no es ingestión persistente.

### 10. LLM mínimo

Ejecute la extracción compacta y luego FLAN-T5-small. Nunca envíe secretos ni datos personales a servicios externos. En este laboratorio el modelo se ejecuta desde Colab y recibe evidencia sintética.

Evalúe la respuesta con esta lista:

- ¿separa hechos de inferencias?;
- ¿cita valores presentes?;
- ¿declara evidencia faltante?;
- ¿ofrece hipótesis alternativa?;
- ¿propone una prueba no destructiva?;
- ¿expresa confianza, no certeza absoluta?

## Entregable

1. tabla comparativa de los cuatro detectores;
2. captura de una traza en Jaeger con tres atributos de red y tres de API;
3. cinco hechos observados;
4. hipótesis principal y alternativa;
5. prompt utilizado y crítica de la salida;
6. siguiente prueba segura.

## Rúbrica (20 puntos)

| Criterio | Puntos |
|---|---:|
| Interpretación correcta de métricas | 4 |
| Comparación MAD/STL/IF/LOF | 4 |
| Navegación y evidencia en Jaeger | 4 |
| Hipótesis respaldadas y alternativas | 4 |
| Uso crítico/seguro del LLM | 4 |

## Problemas frecuentes

- **Jaeger rechaza el JSON:** asegúrese de usar el archivo que termina en `_jaeger.json`; su raíz es `data`.
- **No aparecen trazas tras refrescar:** la carga es temporal; vuelva a importar.
- **STL tarda o falla:** compruebe 4.320 filas, orden temporal y ausencia de nulos.
- **LLM no descarga:** revise conectividad; la hipótesis puede completarse manualmente con el prompt.
- **Salida del LLM es vaga:** reduzca evidencia, exija valores y use una plantilla de respuesta.
"""


PROMPTS = r"""
# Prompts para el análisis con LLM mínimo

## Regla base

No entregue el JSON completo a un modelo pequeño. Extraiga un resumen compacto de una sola traza o incidente. Quite secretos, tokens, payloads y datos personales.

## 1. Extracción sin diagnóstico

> Extrae solamente hechos observables del JSON. Devuelve servicio, operación, duración, estado HTTP, utilización, RTT, pérdida, reintentos y timeouts. No propongas causa y no inventes campos.

## 2. Hipótesis ordenadas

> Con la evidencia suministrada genera tres hipótesis: congestión del enlace, defecto interno del API y lentitud de dependencia externa. Para cada una incluye evidencia a favor, evidencia en contra o ausente, prueba no destructiva y confianza baja/media/alta. Distingue hechos de inferencias.

## 3. Revisor escéptico

> La hipótesis inicial es “congestión del canal”. Intenta refutarla. Señala qué observaciones también serían compatibles con rate limiting, thread-pool exhaustion, DNS lento o proveedor externo. Propón el dato discriminante para cada alternativa.

## 4. Secuencia temporal

> Ordena las señales por tiempo y determina si la secuencia observada apoya: utilización → RTT/pérdida → reintentos → latencia/timeouts → HTTP 504. Si el JSON no permite ordenar algo, indícalo explícitamente.

## 5. Informe de incidente

> Redacta un informe breve con impacto, ventana temporal, hechos, causa probable, hipótesis alternativas, nivel de confianza, acción inmediata reversible y validación posterior. No presentes la causa probable como confirmada.

## Plantilla de evidencia compacta

```json
{
  "trace_id": "...",
  "ventana": "...",
  "api": {"p95_ms": 0, "timeouts_pct": 0, "error_pct": 0, "retry_pct": 0},
  "red": {"util_pct": 0, "rtt_ms": 0, "perdida_pct": 0},
  "spans_error": [{"servicio": "...", "operacion": "...", "status": 504}],
  "detectores": {"mad": true, "stl": true, "isolation_forest": true, "lof": true}
}
```
"""


README = r"""
# Paquete del laboratorio

Empiece por `MANUAL_ESTUDIANTE.md` y abra el notebook en Google Colab. Para la demo visual de Jaeger use `trazas_api_red_congestionada_jaeger.json`. El archivo `trazas_api_red_congestionada_otel.json` conserva la representación OTLP/JSON equivalente.
"""


def validate(jaeger, otlp):
    assert isinstance(jaeger.get("data"), list) and len(jaeger["data"]) == 12
    all_trace_ids = set()
    for t in jaeger["data"]:
        assert len(t["traceID"]) == 32 and all(c in "0123456789abcdef" for c in t["traceID"])
        assert t["traceID"] not in all_trace_ids; all_trace_ids.add(t["traceID"])
        ids = {s["spanID"] for s in t["spans"]}
        assert len(t["spans"]) == 7 and len(ids) == 7
        roots = 0
        for s in t["spans"]:
            assert len(s["spanID"]) == 16 and s["processID"] in t["processes"]
            if not s["references"]: roots += 1
            for ref in s["references"]: assert ref["spanID"] in ids and ref["traceID"] == t["traceID"]
        assert roots == 1
    otel_spans = []
    for rs in otlp["resourceSpans"]:
        for ss in rs["scopeSpans"]: otel_spans.extend(ss["spans"])
    assert len(otel_spans) == 84
    assert {s["traceId"] for s in otel_spans} == all_trace_ids
    for s in otel_spans:
        assert len(s["traceId"]) == 32 and len(s["spanId"]) == 16
        assert int(s["endTimeUnixNano"]) > int(s["startTimeUnixNano"])


def main():
    raw = make_telemetry()
    enriched, results = detect(raw)
    enriched.to_csv(OUT / "telemetria_api_red_congestionada.csv", index=False, date_format="%Y-%m-%dT%H:%M:%SZ")
    results.to_csv(OUT / "resultados_esperados.csv", index=False)
    jaeger, otlp = make_traces(enriched)
    validate(jaeger, otlp)
    (OUT / "trazas_api_red_congestionada_jaeger.json").write_text(json.dumps(jaeger, ensure_ascii=False, indent=2), encoding="utf-8")
    (OUT / "trazas_api_red_congestionada_otel.json").write_text(json.dumps(otlp, ensure_ascii=False, indent=2), encoding="utf-8")
    (OUT / "Laboratorio_API_Red_Congestionada_AIOps_Jaeger_LLM.ipynb").write_text(json.dumps(make_notebook(), ensure_ascii=False, indent=1), encoding="utf-8")
    (OUT / "MANUAL_ESTUDIANTE.md").write_text(textwrap.dedent(MANUAL).strip()+"\n", encoding="utf-8")
    (OUT / "PROMPTS_LLM.md").write_text(textwrap.dedent(PROMPTS).strip()+"\n", encoding="utf-8")
    (OUT / "README.md").write_text(textwrap.dedent(README).strip()+"\n", encoding="utf-8")
    (OUT / "requirements.txt").write_text("numpy\npandas\nmatplotlib\nseaborn\nscikit-learn\nstatsmodels\ntransformers\nsentencepiece\n", encoding="utf-8")
    (OUT / "build_lab_api_congestion.py").write_text(Path(__file__).read_text(encoding="utf-8"), encoding="utf-8")
    zpath = ROOT / "Paquete_Laboratorio_API_Red_Congestionada_Jaeger_LLM.zip"
    with zipfile.ZipFile(zpath, "w", zipfile.ZIP_DEFLATED) as z:
        for p in sorted(OUT.iterdir()): z.write(p, p.name)
    print(json.dumps({"out": str(OUT), "zip": str(zpath), "rows": len(enriched), "incident_rows": int(enriched.is_incident.sum()), "results": results.to_dict("records")}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
